# Urwid html fragment output wrapper for "screen shots"
#    Copyright (C) 2004-2007  Ian Ward
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/


"""HTML PRE-based UI implementation."""

from __future__ import annotations

import html
import typing

from urwid import _deprecation, str_util
from urwid.event_loop import ExitMainLoop
from urwid.util import get_encoding

from .common import AttrSpec, BaseScreen, _browser_href, attr_spec_to_css

if typing.TYPE_CHECKING:
    from typing import Literal

    from urwid import Canvas

    _MouseInput = tuple[str, int, int, int]
    _CursorPosition = tuple[typing.Literal["cursor position"], int, int]
    _DecodedInput = list[str | _MouseInput | _CursorPosition]
    # Imported by name for type checkers, see urwid._deprecation.
    from typing_extensions import deprecated
else:
    from urwid._deprecation import deprecated

# replace control characters with ?'s
_trans_table = str.maketrans(dict.fromkeys(range(32), "?"))

_default_foreground = "black"
_default_background = "light gray"


class HtmlGeneratorSimulationError(Exception):
    """Raised when :class:`HtmlGenerator` is used in a way its simulated screen does not support."""


class HtmlGenerator(BaseScreen):
    """Screen backend that renders each displayed frame as an HTML fragment instead of a real terminal."""

    # class variables
    fragments: typing.ClassVar[list[str]] = []
    sizes: typing.ClassVar[list[tuple[int, int]]] = []
    keys: typing.ClassVar[list[_DecodedInput]] = []
    started = True

    def __init__(self) -> None:
        """Initialize the simulated screen with a 16-color palette."""
        super().__init__()
        self.colors = 16
        self.bright_is_bold = False  # ignored
        self.has_underline = True  # ignored
        self.register_palette_entry(None, _default_foreground, _default_background)

    def set_terminal_properties(
        self,
        colors: int | None = None,
        bright_is_bold: bool | None = None,
        has_underline: bool | None = None,
    ) -> None:
        """Store the given terminal capabilities, keeping each one unchanged where it is left as ``None``."""
        if colors is None:
            colors = self.colors
        if bright_is_bold is None:
            bright_is_bold = self.bright_is_bold
        if has_underline is None:
            has_underline = self.has_underline

        self.colors = colors
        self.bright_is_bold = bright_is_bold
        self.has_underline = has_underline

    def set_input_timeouts(self, *args: typing.Any) -> None:
        """Do nothing; this simulated screen has no real input source to configure timeouts on."""

    def reset_default_terminal_palette(self, *args: typing.Any) -> None:
        """Do nothing; this simulated screen has no real terminal palette to reset."""

    def draw_screen(self, size: tuple[int, int], canvas: Canvas) -> None:
        """Create an html fragment from the render object.

        Append it to HtmlGenerator.fragments list.

        :raises ValueError: *canvas* does not have the number of rows given by *size*.
        """
        # collect output in l
        lines = []

        _cols, rows = size

        if canvas.rows() != rows:
            raise ValueError(rows)

        if canvas.cursor is not None:
            cx, cy = canvas.cursor
        else:
            cx = cy = -1  # no cursor: matches no row

        for y, row in enumerate(canvas.content()):
            col = 0

            for a, _cs, run in row:
                t_run = run.decode(get_encoding(), "replace").translate(_trans_table)
                aspec = self.resolve_attr(a, {1: 1, 16: 0, 88: 2, 256: 3, 2**24: 4}[self.colors])

                if y == cy and col <= cx:
                    run_width = str_util.calc_width(t_run, 0, len(t_run))
                    if col + run_width > cx:
                        lines.append(html_span(t_run, aspec, cx - col))
                    else:
                        lines.append(html_span(t_run, aspec))
                    col += run_width
                else:
                    lines.append(html_span(t_run, aspec))

            lines.append("\n")

        # add the fragment to the list
        self.fragments.append(f"<pre>{''.join(lines)}</pre>")

    def get_cols_rows(self) -> tuple[int, int]:
        """Return the next screen size in HtmlGenerator.sizes.

        :raises HtmlGeneratorSimulationError: the list of simulated sizes is exhausted.
        """
        if not self.sizes:
            raise HtmlGeneratorSimulationError("Ran out of screen sizes to return!")
        return self.sizes.pop(0)

    @typing.overload
    def get_input(self, raw_keys: Literal[False]) -> _DecodedInput: ...

    @typing.overload
    def get_input(self, raw_keys: Literal[True]) -> tuple[_DecodedInput, list[int]]: ...

    def get_input(self, raw_keys: bool = False) -> _DecodedInput | tuple[_DecodedInput, list[int]]:
        """Return the next list of keypresses in HtmlGenerator.keys.

        :raises ExitMainLoop: the list of simulated key presses is exhausted.
        """
        if not self.keys:
            raise ExitMainLoop
        if raw_keys:
            return (self.keys.pop(0), [])
        return self.keys.pop(0)


def html_span(s: str, aspec: AttrSpec, cursor: int = -1) -> str:
    """Wrap *s* in an HTML ``<span>`` styled from *aspec*, splitting it around *cursor* when given a valid index.

    Each non-empty piece is also wrapped in an ``<a>`` element when *aspec* has a hyperlink
    with a scheme a browser may follow (see :ref:`hyperlinks`).
    """
    html_fg, html_bg, extra = attr_spec_to_css(aspec)
    href = _browser_href(aspec.hyperlink) if aspec.hyperlink is not None else None

    def _span(fg: str, bg: str, string: str) -> str:
        if not s:
            return ""
        span = f'<span style="color:{fg};background:{bg}{extra}">{html.escape(string)}</span>'
        if href is None or not string:
            return span
        return f'<a href="{html.escape(href, quote=True)}">{span}</a>'

    if cursor >= 0:
        c_off, _ign = str_util.calc_text_pos(s, 0, len(s), cursor)
        c2_off = str_util.move_next_char(s, c_off, len(s))
        return (
            _span(html_fg, html_bg, s[:c_off])
            + _span(html_bg, html_fg, s[c_off:c2_off])
            + _span(html_fg, html_bg, s[c2_off:])
        )

    return _span(html_fg, html_bg, s)


@deprecated(
    "screenshot_init patches curses.Screen and raw.Screen in place. "
    "Assign HtmlGenerator to your application's screen manually instead. "
    "Deprecated since urwid 4.1.8, will be removed in version 6.0.",
    category=None,
)
def screenshot_init(
    sizes: list[tuple[int, int]],
    keys: list[_DecodedInput],
) -> None:
    """Replace display.curses.Screen and display.raw.Screen class with HtmlGenerator.

    Call this function before executing an application that uses
    display.curses.Screen to have that code use HtmlGenerator instead.

    :param sizes: list of ( columns, rows ) tuples to be returned by each call to HtmlGenerator.get_cols_rows()
    :param keys: list of lists of keys to be returned by each call to HtmlGenerator.get_input()
    :raises TypeError: *sizes* is not a list of integer pairs, or *keys* is not a list of lists of strings.
    :raises ValueError: a size has a non-positive number of columns or rows.

    Lists of keys may include "window resize" to force the application to
    call get_cols_rows and read a new screen size.

    For example, the following call will prepare an application to:
     1. start in 80x25 with its first call to get_cols_rows()
     2. take a screenshot when it calls draw_screen(..)
     3. simulate 5 :kbd:`down` keys from get_input()
     4. take a screenshot when it calls draw_screen(..)
     5. simulate keys :kbd:`a`, :kbd:`b`, :kbd:`c` and a ``"window resize"`` event
     6. resize to 20x10 on its second call to get_cols_rows()
     7. take a screenshot when it calls draw_screen(..)
     8. simulate a "Q" keypress to quit the application

    screenshot_init( [ (80,25), (20,10) ],
        [ ["down"]*5, ["a","b","c","window resize"], ["Q"] ] )

    .. deprecated:: 4.1.8
        Patching ``display.curses.Screen``/``display.raw.Screen`` in place is deprecated and will stop working in
        version 6.0. Assign :class:`HtmlGenerator` to your application's screen manually instead.
    """
    _deprecation.warn(
        "screenshot_init patches curses.Screen and raw.Screen in place. "
        "Assign HtmlGenerator to your application's screen manually instead.",
        since="4.1.8",
        removed_in="6.0",
    )
    for row, col in sizes:
        if not isinstance(row, int):
            raise TypeError(f"sizes must be list[tuple[int, int]], with values >0 : {row!r}")
        if row <= 0:
            raise ValueError(f"sizes must be list[tuple[int, int]], with values >0 : {row!r}")
        if not isinstance(col, int):
            raise TypeError(f"sizes must be list[tuple[int, int]], with values >0 : {col!r}")
        if col <= 0:
            raise ValueError(f"sizes must be list[tuple[int, int]], with values >0 : {col!r}")

    for line in keys:
        if not isinstance(line, list):
            raise TypeError(f"keys must be list[list[str]]: {line!r}")
        for k in line:
            if not isinstance(k, str):
                raise TypeError(f"keys must be list[list[str]]: {k!r}")

    from . import raw

    try:
        from . import curses
    except (ImportError, AttributeError):
        pass  # the stdlib "curses" module is not available on this platform (e.g. Windows)
    else:
        curses.Screen = HtmlGenerator  # type: ignore[assignment,misc]

    raw.Screen = HtmlGenerator  # type: ignore[assignment,misc]

    HtmlGenerator.sizes = sizes
    HtmlGenerator.keys = keys


def screenshot_collect() -> list[str]:
    """Return screenshots as a list of HTML fragments."""
    fragments = HtmlGenerator.fragments
    HtmlGenerator.fragments = []
    return fragments
