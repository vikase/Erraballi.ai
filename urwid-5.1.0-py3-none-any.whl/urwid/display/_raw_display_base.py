# Urwid raw display module
#    Copyright (C) 2004-2009  Ian Ward
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/


"""Direct terminal UI implementation."""

from __future__ import annotations

import abc
import base64
import contextlib
import dataclasses
import errno
import functools
import operator
import os
import pathlib
import platform
import re
import selectors
import signal
import socket
import stat
import struct
import sys
import typing

from urwid import _deprecation, signals, str_util, util
from urwid._selectors import read_selector

from . import escape
from .common import (
    _COLOR_VALUES_88,
    _COLOR_VALUES_256,
    _RESOLVED_ATTRS_LIMIT,
    UNPRINTABLE_C1_TRANS_TABLE,
    UNPRINTABLE_TRANS_TABLE,
    UPDATE_PALETTE_ENTRY,
    AttrSpec,
    BaseScreen,
    RealTerminal,
)

if typing.TYPE_CHECKING:
    from collections.abc import Callable, Hashable, Iterable, Mapping, Sequence
    from types import FrameType
    from typing import Literal

    from urwid import Canvas, EventLoop

    from .common import Hyperlink

    _MouseInput = tuple[str, int, int, int]
    _CursorPosition = tuple[typing.Literal["cursor position"], int, int]
    _PrivateModeReport = tuple[typing.Literal["private mode report"], str, int]
    _KeyboardProtocolReport = tuple[typing.Literal["keyboard protocol report"], int]
    _ModifyKeysReport = tuple[typing.Literal["modify keys report"], int, int | None]
    _DeviceAttributesReport = tuple[typing.Literal["device attributes"], tuple[int, ...]]
    _TerminalReport = _PrivateModeReport | _KeyboardProtocolReport | _ModifyKeysReport | _DeviceAttributesReport
    _DecodedInput = list[str | _MouseInput | _CursorPosition]
    _DecodedInputWithReports = list[str | _MouseInput | _CursorPosition | _TerminalReport]

IS_WINDOWS = sys.platform == "win32"
IS_WSL = (sys.platform == "linux") and ("wsl" in platform.platform().lower())

# signal has no SIGWINCH on Windows; _win32_raw_display passes its own signum explicitly, so this
# default is only ever actually used on POSIX.
_SIGWINCH = getattr(signal, "SIGWINCH", 28)

_ColorCount = typing.Literal[1, 16, 88, 256, 16777216]

# Terminals that implement SGR 90-97 / 100-107 bright colors without needing bold/blink.
_INDEPENDENT_BRIGHT_FAMILIES = frozenset(
    {
        "alacritty",
        "cygwin",
        "eterm",
        "foot",
        "ghostty",
        "gnome",
        "iterm",
        "iterm2",
        "kitty",
        "konsole",
        "mintty",
        "mlterm",
        "putty",
        "rxvt",
        "st",
        "terminator",
        "tmux",
        "vte",
        "wezterm",
        "xfce",
        "xterm",
    }
)
_TRUECOLOR_FAMILIES = frozenset(
    {
        "alacritty",
        "contour",
        "foot",
        "ghostty",
        "iterm",
        "iterm2",
        "kitty",
        "wezterm",
    }
)
_NO_UNDERLINE_FAMILIES = frozenset({"dumb", "unknown", "vt52"})
# Windows 10 TH2 (1511) gained 256-color VT; 1703-era build 14931 gained 24-bit color.
_WINDOWS_256COLOR_BUILD = 10586
_WINDOWS_TRUECOLOR_BUILD = 14931
_TRUECOLOR_TERM_PROGRAMS = frozenset({"hyper", "tabby", "vscode", "vscode-insiders"})

# Compiled terminfo entries, as term(5) describes them.
# ncurses' built-in search path on common systems, searched after TERMINFO, ~/.terminfo and TERMINFO_DIRS.
_TERMINFO_SYSTEM_DIRS = ("/etc/terminfo", "/lib/terminfo", "/usr/share/terminfo", "/usr/lib/terminfo")
# Header magic -> struct format of one numeric capability: the legacy format has 16-bit numbers,
# the ncurses 6.1 extended number format has 32-bit numbers.
_TERMINFO_NUMBER_FORMATS: Mapping[int, str] = {0o432: "<h", 0o1036: "<i"}
_TERMINFO_HEADER = struct.Struct("<6h")
_TERMINFO_COLORS_INDEX = 13  # position of "colors" among the predefined numeric capabilities
_TERMINFO_MAX_SIZE = 32768  # bytes read from an entry: the largest entry ncurses accepts
# Minimum terminfo "colors" value -> the colour count it allows; 8-colour terminals use bold for the bright half.
_TERMINFO_COLOR_COUNTS: Sequence[tuple[int, _ColorCount]] = ((16777216, 16777216), (256, 256), (88, 88), (8, 16))

# ANSI SGR base codes (ECMA-48 / ISO 6429): 30-37 selects a standard foreground color, 90-97 a
# bright one without needing bold; 40-47 selects a standard background color, 100-107 a bright
# one. AttrSpec numbers its 16 basic colors 0-15, with 8-15 being "the bright half", so
# _SGR_BRIGHT_OFFSET is subtracted from the AttrSpec number before adding the bright SGR base.
_SGR_FG_BASE = 30
_SGR_FG_BRIGHT_BASE = 90
_SGR_BG_BASE = 40
_SGR_BG_BRIGHT_BASE = 100
_SGR_BRIGHT_OFFSET = 8

# Index into the (basic, mono, high_88, high_256, high_true) tuple that
# BaseScreen.register_palette_entry() emits via UPDATE_PALETTE_ENTRY, keyed by this screen's
# current color count.
_ATTRSPEC_INDEX_BY_COLORS: Mapping[_ColorCount, int] = {16: 0, 1: 1, 88: 2, 256: 3, 16777216: 4}


@dataclasses.dataclass(frozen=True)
class TerminalProperties:
    """Capabilities inferred from TERM, its terminfo entry and standard colour environment variables."""

    colors: _ColorCount
    has_underline: bool
    fg_bright_is_bold: bool
    bg_bright_is_blink: bool
    back_color_erase: bool


@dataclasses.dataclass
class TermModes:
    """Terminal modes negotiated with the real host terminal (counterpart to `vterm.TermModes`).

    None: sentinel, resolved by a DECRPM reply (see escape.PrivateMode) or an explicit Screen.__init__ arg.
    """

    alternate_buffer: bool | None = None
    mouse_reporting: bool | None = None
    mouse_sgr_mode: bool | None = None
    focus_reporting: bool | None = None
    bracketed_paste: bool | None = None
    synchronized_output: bool | None = None
    grapheme_clustering: bool | None = None
    # Resolved by the replies to the keyboard protocol queries, which are sent only for Screen(extended_keys=True).
    kitty_keyboard: bool | None = None
    modify_other_keys: bool | None = None

    # escape.PrivateMode member -> the field it resolves.
    _FIELDS: typing.ClassVar[Mapping[str, str]] = {
        escape.PrivateMode.ALTERNATE_SCREEN_BUFFER: "alternate_buffer",
        escape.PrivateMode.MOUSE_REPORTING: "mouse_reporting",
        escape.PrivateMode.MOUSE_SGR_MODE: "mouse_sgr_mode",
        escape.PrivateMode.FOCUS_REPORTING: "focus_reporting",
        escape.PrivateMode.BRACKETED_PASTE: "bracketed_paste",
        escape.PrivateMode.SYNCHRONIZED_OUTPUT: "synchronized_output",
        escape.PrivateMode.GRAPHEME_CLUSTERING: "grapheme_clustering",
    }

    def set_from_codes(self, *response: tuple[str, int]) -> frozenset[str]:
        """Apply DECRPM (mode, value) pairs; return the field names newly resolved to supported."""
        newly_supported = set()
        for mode, value in response:
            field = self._FIELDS.get(mode)
            if field is None:
                continue
            was_unresolved = getattr(self, field) is None
            supported = value in escape.DECRQM_SETTABLE_VALUES
            setattr(self, field, supported)
            if was_unresolved and supported:
                newly_supported.add(field)
        return frozenset(newly_supported)


def _term_families(term: str) -> frozenset[str]:
    """Name tokens from a TERM value.

    ``screen.xterm-256color`` yields ``screen``, ``xterm`` and ``256color``.
    ``rxvt-unicode-256color`` yields ``rxvt``, ``unicode`` and ``256color``.
    ``xterm-kitty`` yields ``xterm`` and ``kitty``.
    """
    families: set[str] = set()
    for part in term.lower().split("."):
        if part:
            families.update(token for token in part.split("-") if token)
    return frozenset(families)


# ``linux``, optionally with a kernel version as in the terminfo names ``linux2.6`` and ``linux3.0``,
# then the end of the name or a ``-`` or ``.`` suffix.
_LINUX_CONSOLE_TERM = re.compile(r"linux(?:\d+(?:\.\d+)*)?(?:[-.]|$)", re.IGNORECASE)


def _is_linux_console(term: str) -> bool:
    """Tell whether a TERM value names the Linux virtual console.

    ``linux``, ``linux-16color``, ``linux.utf8`` and the versioned terminfo names such as ``linux2.6.26`` do.
    A multiplexer that names its outer terminal, such as ``screen.linux``, is not the console.
    """
    return _LINUX_CONSOLE_TERM.match(term) is not None


def _rejects_osc(term: str) -> bool:
    """Tell whether the terminal a TERM value names cannot take a window title or clipboard sequence.

    The Linux virtual console reads only its own palette sequences and prints the others as text.
    fbterm has neither a window title nor a clipboard.
    A ``dumb`` terminal reads no escape sequences.
    On Windows, TERM does not describe the console, so only the Linux console names count there.
    """
    return _is_linux_console(term) or (term.lower() in {"dumb", "fbterm"} and not IS_WINDOWS)


def _parse_force_color(value: str) -> _ColorCount:
    """Map FORCE_COLOR / CLICOLOR_FORCE to a color count (chalk / supports-color convention)."""
    normalized = value.strip().lower()
    if normalized in {"0", "false", "no"}:
        return 1
    if normalized in {"", "1", "true", "yes"}:
        return 16
    if normalized == "2":
        return 256
    if normalized == "3":
        return 16777216
    return 16


def _windows_version() -> tuple[int, int, int] | None:
    if sys.platform != "win32":
        return None
    # pyrefly: ignore[missing-attribute]  # Windows only, behind a platform check
    version = sys.getwindowsversion()  # pylint: disable=no-member
    return (version.major, version.minor, version.build)


def _windows_console_colors(version: tuple[int, int, int] | None) -> _ColorCount | None:
    """Color depth of the Windows console VT host, if any."""
    if version is None or version < (10, 0, 0):
        return None
    if version >= (10, 0, _WINDOWS_TRUECOLOR_BUILD):
        return 16777216
    if version >= (10, 0, _WINDOWS_256COLOR_BUILD):
        return 256
    return 16


def _truecolor_host(environ: Mapping[str, str]) -> bool:
    """Hosts that speak 24-bit SGR even when TERM still says xterm-256color."""
    if (colorterm := environ.get("COLORTERM")) and colorterm.lower() in {"truecolor", "24bit"}:
        return True
    if environ.get("WT_SESSION") or environ.get("WT_PROFILE_ID"):
        return True
    if environ.get("ConEmuANSI", "").lower() in {"on", "1"} or environ.get("ConEmuPID"):
        return True
    return environ.get("TERM_PROGRAM", "").lower() in _TRUECOLOR_TERM_PROGRAMS


def _colors_from_term(term: str, families: frozenset[str]) -> _ColorCount:
    term_l = term.lower()
    if not term_l:
        return 16
    if families & _NO_UNDERLINE_FAMILIES or term_l in _NO_UNDERLINE_FAMILIES:
        return 1
    if "direct" in term_l or families & _TRUECOLOR_FAMILIES:
        return 16777216
    if "256color" in term_l:
        return 256
    if "88color" in term_l:
        return 88
    return 16


def _parse_terminfo_colors(data: bytes) -> int | None:
    """Return the ``colors`` capability of a compiled terminfo entry.

    The entry is untrusted data, so its header is checked before its sizes are used as offsets.

    :returns: the number of colours, or None when the entry has no ``colors``.
    :raises ValueError: the entry is not in a compiled terminfo format, or it is shorter than its header says.
    """
    if len(data) < _TERMINFO_HEADER.size:
        raise ValueError
    magic, *sizes = _TERMINFO_HEADER.unpack_from(data)
    names_size, booleans_count, numbers_count, strings_count, strings_size = sizes
    number_format = _TERMINFO_NUMBER_FORMATS.get(magic)
    if number_format is None or min(sizes) < 0:
        raise ValueError
    number_size = struct.calcsize(number_format)
    numbers_offset = _TERMINFO_HEADER.size + names_size + booleans_count
    numbers_offset += numbers_offset % 2  # the numbers start on an even byte
    # The string offsets are 16-bit and followed by the string table.
    if numbers_offset + numbers_count * number_size + 2 * strings_count + strings_size > len(data):
        raise ValueError
    if numbers_count <= _TERMINFO_COLORS_INDEX:
        return None
    (colors,) = struct.unpack_from(number_format, data, numbers_offset + _TERMINFO_COLORS_INDEX * number_size)
    # -1 marks an absent capability and -2 a cancelled one
    return colors if colors > 0 else None


def _read_terminfo_entry(path: pathlib.Path) -> bytes | None:
    """Return the start of the regular file at *path*.

    Opening a device, even briefly, can disturb its other users: a serial port asserts DTR.
    So a device is never opened, even if the entry is replaced while it is being read:

    - The path is resolved with realpath(), which reads links without opening anything.
    - stat() checks that the resolved path is a regular file.
    - Each component is opened through the previous directory with O_NOFOLLOW, so a symlink planted afterwards fails.
    - O_NONBLOCK and O_NOCTTY stop a FIFO from blocking and a tty from becoming the controlling terminal.

    :returns: up to ``_TERMINFO_MAX_SIZE`` bytes, or None when *path* is missing, unreadable or not a regular file.
    """
    try:
        real = os.path.realpath(path, strict=True)
        if not stat.S_ISREG(pathlib.Path(real).stat().st_mode):
            return None
        *directories, name = pathlib.PurePath(real).parts
        fd = os.open(directories[0], os.O_RDONLY | os.O_DIRECTORY)
        try:
            for directory in directories[1:]:
                parent, fd = fd, -1
                try:
                    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
                finally:
                    os.close(parent)
            entry = os.open(name, os.O_RDONLY | os.O_NONBLOCK | os.O_NOCTTY | os.O_NOFOLLOW, dir_fd=fd)
        finally:
            if fd >= 0:
                os.close(fd)
    # ValueError: a directory from the environment holds NUL or a lone surrogate.
    # RecursionError: realpath() before Python 3.13 recurses once per link of a long symlink chain.
    # NotImplementedError: dir_fd is unavailable at run time, as on macOS 10.9.
    except (OSError, ValueError, RecursionError, NotImplementedError):
        return None
    try:
        return os.read(entry, _TERMINFO_MAX_SIZE) if stat.S_ISREG(os.fstat(entry).st_mode) else None
    except OSError:
        return None
    finally:
        os.close(entry)


def _terminfo_colors(term: str, environ: Mapping[str, str]) -> _ColorCount | None:
    """Return the colour count the terminfo entry of *term* allows.

    The stdlib ``curses.setupterm()`` loads one entry per process and ignores later terminal names,
    so the compiled entry is read directly.
    Directories are searched in ncurses' order: ``TERMINFO``, ``$HOME/.terminfo``, ``TERMINFO_DIRS``,
    then the system directories.
    In each one the entry is looked up under its first letter, and under that letter's hexadecimal code as on macOS.
    The first valid entry found is used, and a malformed one is passed over as ncurses does.

    Native Windows has no terminfo database, and a Win32 path can name a device such as ``COM1`` by its file name,
    so nothing is looked up there.

    :returns: the colour count, or None when no valid entry is found or it allows fewer than 8 colours.
    """
    if IS_WINDOWS:
        return None
    # TERM comes from the environment and becomes a file name. Only the characters terminal names use are accepted,
    # so it cannot name another directory or a path the file system cannot encode.
    if not term or not term.isascii() or not all(char.isalnum() or char in "+-._" for char in term):
        return None
    directories: list[pathlib.Path] = []
    if terminfo := environ.get("TERMINFO"):
        directories.append(pathlib.Path(terminfo))
    if home := environ.get("HOME"):
        directories.append(pathlib.Path(home, ".terminfo"))
    directories.extend(pathlib.Path(entry) for entry in environ.get("TERMINFO_DIRS", "").split(os.pathsep) if entry)
    directories.extend(pathlib.Path(directory) for directory in _TERMINFO_SYSTEM_DIRS)
    for directory in directories:
        for subdirectory in (term[0], f"{ord(term[0]):x}"):
            if (data := _read_terminfo_entry(directory / subdirectory / term)) is None:
                continue
            try:
                colors = _parse_terminfo_colors(data)
            except ValueError:  # malformed: ncurses passes over it too
                continue
            if colors is None:
                return None
            return next((count for minimum, count in _TERMINFO_COLOR_COUNTS if colors >= minimum), None)
    return None


def detect_term_colors(
    term: str | None = None,
    environ: Mapping[str, str] | None = None,
    *,
    windows_version: tuple[int, int, int] | None = None,
) -> _ColorCount:
    """Detect the colour count of the terminal.

    Sources, the first that decides wins:

    - ``NO_COLOR``, then ``FORCE_COLOR`` / ``CLICOLOR_FORCE``, then ``CLICOLOR=0``.
    - A monochrome TERM such as ``dumb``.
    - A 24-bit host: ``COLORTERM=truecolor``, Windows Terminal, ConEmu, VS Code, or Windows 10 from build 14931.
    - Any other ``COLORTERM``, which means at least 256 colours.
    - The Windows 10 console from build 10586, which has 256 colours.
    - TERM itself.

    TERM gives a count by its name, matched by family so ``gnome-256color``, ``konsole-direct``
    and ``rxvt-unicode-256color`` are recognized.
    The ``colors`` capability of its terminfo entry raises that count and never lowers it.
    The entry is searched in the ``TERMINFO``, ``$HOME/.terminfo`` and ``TERMINFO_DIRS`` directories of *environ*,
    then in the system terminfo directories; native Windows has no terminfo lookup.

    :param term: the terminal name; ``TERM`` from *environ* when None.
    :param environ: the environment; :data:`os.environ` when None.
    :param windows_version: the Windows version as (major, minor, build); the running system's when None.
    :returns: the colour count: 1, 16, 88, 256 or 16777216.

    >>> detect_term_colors("xterm", {"FORCE_COLOR": "3"})
    16777216
    >>> detect_term_colors("xterm-256color", {"NO_COLOR": "1"})
    1
    """
    env = os.environ if environ is None else environ
    force = env.get("FORCE_COLOR") or env.get("CLICOLOR_FORCE")
    if env.get("NO_COLOR") or (env.get("CLICOLOR") == "0" and not force):
        return 1
    if force:
        return _parse_force_color(force)
    term_value = env.get("TERM", "") if term is None else term
    term_colors = _colors_from_term(term_value, _term_families(term_value))
    # The name rules know hosts whose entries understate them, such as the truecolor families.
    if (terminfo_colors := _terminfo_colors(term_value, env)) is not None:
        term_colors = max(term_colors, terminfo_colors)
    if term_colors == 1:
        return 1
    win_colors = _windows_console_colors(_windows_version() if windows_version is None else windows_version)
    if _truecolor_host(env) or win_colors == 16777216:
        return 16777216
    # Any other COLORTERM, or the Windows console, sets the minimum.
    minimum: _ColorCount = 256 if env.get("COLORTERM") else win_colors or 1
    return max(term_colors, minimum)


def detect_terminal_properties(
    term: str | None = None,
    environ: Mapping[str, str] | None = None,
    *,
    windows_version: tuple[int, int, int] | None = None,
) -> TerminalProperties:
    """Detect raw-display capabilities from TERM and standard colour environment variables.

    The colour count comes from :func:`detect_term_colors`.
    TERM names are matched by family, so ``screen.xterm-256color`` is treated as both screen and xterm.

    On Windows 10 and later the console VT host is used when TERM is empty or generic.
    Windows Terminal (``WT_SESSION``), ConEmu and VS Code's terminal are treated as VT hosts even
    when TERM still reports ``xterm-256color``.
    """
    env = os.environ if environ is None else environ
    term_value = env.get("TERM", "") if term is None else term
    families = _term_families(term_value)
    term_l = term_value.lower()
    if windows_version is None:
        windows_version = _windows_version()
    win_colors = _windows_console_colors(windows_version)
    vt_host = _truecolor_host(env) or win_colors in {256, 16777216}

    has_underline = not bool(families & _NO_UNDERLINE_FAMILIES)
    linux_console = _is_linux_console(term_value)
    fg_bright_is_bold = not bool(families & _INDEPENDENT_BRIGHT_FAMILIES)
    if vt_host and not linux_console:
        fg_bright_is_bold = False
        has_underline = True
    bg_bright_is_blink = linux_console
    back_color_erase = "bce" in term_l or not families & {"screen", "dumb", "unknown"}

    return TerminalProperties(
        colors=detect_term_colors(term_value, env, windows_version=windows_version),
        has_underline=has_underline,
        fg_bright_is_bold=fg_bright_is_bold,
        bg_bright_is_blink=bg_bright_is_blink,
        back_color_erase=back_color_erase,
    )


# the start of a raw sequence in a charset "U" run: ESC or a C1 control as UTF-8, and only ESC in the
# single and double byte encodings, where bytes 0x80-0x9f are glyphs of the IBM PC character set or parts of characters
_RAW_SEQUENCE_UTF8 = re.compile(rb"\x1b|\xc2[\x80-\x9f]")
_RAW_SEQUENCE_BYTES = re.compile(rb"\x1b")
# C0 and C1 control characters and DEL: in a window title, BEL, ESC or ST would end the title and start a sequence
_TITLE_CONTROLS = re.compile("[\x00-\x1f\x7f-\x9f]")
# bytes a terminal reading 8-bit controls takes as C1 controls, such as 0x9c (ST) and 0x9b (CSI)
_C1_BYTES = re.compile(rb"[\x80-\x9f]")


@typing.runtime_checkable
class SupportsFileno(typing.Protocol):
    """Object that can be used to obtain an OS-level file descriptor."""

    def fileno(self) -> int:
        """Return the underlying OS-level file descriptor."""
        ...


class TextWriter(typing.Protocol):
    """Text output stream used by the raw display."""

    def write(self, data: str, /) -> object:
        """Write `data` to the stream."""

    def flush(self) -> object:
        """Flush buffered output to the stream."""


class Screen(BaseScreen, RealTerminal):
    """Shared base for the raw POSIX and Windows screen backends that talk directly to the terminal."""

    _term_input_file: SupportsFileno
    _term_output_file: TextWriter

    def __init__(
        self,
        input: SupportsFileno,  # noqa: A002  # pylint: disable=redefined-builtin
        output: TextWriter,
        bracketed_paste_mode: bool | None = None,
        focus_reporting: bool | None = None,
        extended_keys: bool = False,
    ) -> None:
        """Initialize a screen that directly prints escape codes to an output terminal.

        :param input: the terminal input, read through its file descriptor.
        :param output: the terminal output, which the escape codes are written to.
        :param bracketed_paste_mode: enable bracketed paste (`begin`/`end paste` keystrokes).
            None (default) auto-detects via DECRQM and enables it once confirmed supported;
            pass True/False to force it without probing.
        :param focus_reporting: enable focus reporting (`focus in`/`focus out` keystrokes).
            None (default) auto-detects via DECRQM and enables it once confirmed supported;
            pass True/False to force it without probing.
        :param extended_keys: report the keys the legacy encodings cannot tell apart, such as ``'ctrl enter'``
            and ``'ctrl i'`` apart from ``'tab'``, through the keyboard protocol the terminal supports.
            Ctrl+C and Ctrl+Z then arrive as keys instead of signals; see :ref:`extended-keys`.
        """
        super().__init__()

        self._partial_codes: list[int] = []
        self.modes = TermModes(bracketed_paste=bracketed_paste_mode, focus_reporting=focus_reporting)
        self.extended_keys = extended_keys
        # the keyboard protocol queries were sent and the Primary DA reply that ends their answers has not arrived
        self._keyboard_query_pending = False
        # the private modes queried by the last start and not answered yet
        self._mode_queries_pending: set[str] = set()
        # the modifyOtherKeys value the terminal reported, written back when the screen stops
        self._modify_other_keys_reported: int | None = None
        self._keyboard_protocol_enabled: Literal["kitty", "modify other keys"] | None = None
        # escape sequence per canvas run attribute, filled as attributes are drawn
        self._pal_escape: dict[Hashable, str] = {}
        self._modified_palette_entries: set[int] = set()
        # Connected through a weak reference: a bound method would be a reference cycle back to this screen,
        # keeping its sockets open until the cyclic garbage collector happened to run.
        signals.connect_signal(self, UPDATE_PALETTE_ENTRY, type(self)._on_update_palette_entry, weak_args=(self,))
        self.term = os.environ.get("TERM", "")
        self.colors = detect_term_colors(self.term, os.environ)
        properties = detect_terminal_properties(self.term, os.environ)
        self.has_underline = properties.has_underline
        self.fg_bright_is_bold = properties.fg_bright_is_bold
        self.bg_bright_is_blink = properties.bg_bright_is_blink
        self.back_color_erase = properties.back_color_erase
        # OSC 8 hyperlinks are drawn only when the application turns them on: no query exists
        self.hyperlinks = False
        # the window title set_title() asked for, shown while the screen runs
        self._title: str | None = None
        # the title the terminal had before is saved, and is given back when the screen stops
        self._title_saved = False
        self.prev_input_resize = 0
        self.set_input_timeouts()
        self.screen_buf: list[list[tuple[Hashable, Literal["0", "U"] | None, bytes]]] | None = None
        # screen_buf with each attribute as its escape sequence: rows are compared by what the terminal shows,
        # so a palette change redraws only the rows it changes
        self._drawn_rows: list[list[tuple[str, Literal["0", "U"] | None, bytes]]] = []
        self._screen_buf_canvas: Canvas | None = None
        self._resized = False
        self.maxrow: int | None = None
        self._alternate_buffer = False
        self._mouse_tracking_enabled = False
        self.last_bstate = 0
        self._setup_G1_done = False
        self._rows_used: int | None = None
        self._cy = 0
        self.register_palette_entry(None, "default", "default")
        self._next_timeout: float | None = None
        self.signal_handler_setter = signal.signal

        # Our connections to the world
        self._term_output_file = output
        self._term_input_file = input

        # pipe for signalling external event loops about resize events
        self._resize_pipe_rd, self._resize_pipe_wr = socket.socketpair()
        self._resize_pipe_rd.setblocking(False)
        self._resize_pipe_wr.setblocking(False)

    def __del__(self) -> None:
        self._resize_pipe_rd.close()
        self._resize_pipe_wr.close()

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}(input={self._term_input_file}, output={self._term_output_file})>"

    def _sigwinch_handler(self, signum: int = _SIGWINCH, frame: FrameType | None = None) -> None:
        """Record a terminal resize and wake the input loop.

        This runs at an arbitrary point of the program (a signal handler, or the console reader thread on Windows),
        so it only sets a flag and writes to the wake-up socket.
        :meth:`parse_input` reports the resize and drops the screen buffer in the thread that draws the screen.

        :param signum: the signal number; it is not used.
        :param frame: will always be None when the GLib event loop is being used.
        """
        self._resized = True
        self._wake_input_loop()

    def _wake_input_loop(self) -> None:
        """Make the input descriptors readable, without blocking when a wake-up is already pending."""
        with contextlib.suppress(BlockingIOError):
            self._resize_pipe_wr.send(b"R")

    @property
    def _term_input_io(self) -> SupportsFileno | None:
        if isinstance(self._term_input_file, SupportsFileno):
            return self._term_input_file
        return None

    def _input_fileno(self) -> int | None:
        """Return the fileno of the input stream, or None if it doesn't have one.

        A stream without a fileno can't participate in whatever.
        """
        if isinstance(self._term_input_file, SupportsFileno):
            return self._term_input_file.fileno()

        return None

    def _on_update_palette_entry(self, name: Hashable, *attrspecs: AttrSpec) -> None:
        # any drawn attribute may inherit colors from the changed entry; the next draw compares every row again
        self._pal_escape.clear()
        self._screen_buf_canvas = None

    def set_input_timeouts(
        self,
        max_wait: float | None = None,
        complete_wait: float = 0.125,
        resize_wait: float = 0.125,
    ) -> None:
        """Set the get_input timeout values.

        All values are in floating point numbers of seconds.

        :param max_wait: amount of time in seconds to wait for input when there is no input pending, wait forever if
            None
        :param complete_wait: amount of time in seconds to wait when get_input detects an incomplete escape sequence at
            the end of the available input
        :param resize_wait: amount of time in seconds to wait for more input after receiving two screen resize requests
            in a row to stop Urwid from consuming 100% cpu during a gradual window resize operation
        """
        self.max_wait = max_wait
        if max_wait is not None:
            if self._next_timeout is None:
                self._next_timeout = max_wait
            else:
                self._next_timeout = min(self._next_timeout, max_wait)
        self.complete_wait = complete_wait
        self.resize_wait = resize_wait

    def set_mouse_tracking(self, enable: bool = True) -> None:
        """
        Enable (or disable) mouse tracking.

        After calling this function get_input will include mouse click events along with keystrokes.
        """
        if enable == self._mouse_tracking_enabled:
            return

        self._mouse_tracking(enable)

    def _mouse_tracking(self, enable: bool) -> None:
        """Write the mouse tracking escape sequences and track `_mouse_tracking_enabled`.

        A no-op when *enable* is True but mouse reporting was detected unsupported -- there is
        nothing to enable, and the tracked state has to agree.
        """
        if enable and self.modes.mouse_reporting is False:
            self._mouse_tracking_enabled = False
            return
        self.write(escape.MOUSE_TRACKING_ON if enable else escape.MOUSE_TRACKING_OFF)
        self._mouse_tracking_enabled = enable

    def _is_real_terminal(self) -> bool:
        """Whether input/output are a real terminal that could answer a DECRQM probe.

        Overridden on Windows, whose input is a socket, not a descriptor `os.isatty` can inspect.
        """
        fd = self._input_fileno()
        return fd is not None and os.isatty(fd)

    # TermModes field -> the sequence that enables it, once confirmed supported from a sentinel.
    _PRIVATE_MODE_ENABLE_SEQUENCE: typing.ClassVar[Mapping[str, str]] = {
        "bracketed_paste": escape.PrivateMode.BRACKETED_PASTE.enable_seq,
        "focus_reporting": escape.PrivateMode.FOCUS_REPORTING.enable_seq,
    }

    def _detect_terminal_modes(self) -> None:
        """Send DECRQM queries for the private modes still at their sentinel; does not wait for a reply.

        Replies are recognized later, during normal `parse_input()`
        (see `escape.KeyqueueTrie.read_private_mode_report`, `_apply_terminal_reports()`).
        With ``extended_keys``, the kitty keyboard protocol and modifyOtherKeys are queried as well, once.
        """
        if not self._is_real_terminal():
            return

        modes = [
            escape.PrivateMode.SYNCHRONIZED_OUTPUT,
            escape.PrivateMode.GRAPHEME_CLUSTERING,
            escape.PrivateMode.ALTERNATE_SCREEN_BUFFER,
            escape.PrivateMode.MOUSE_REPORTING,
            escape.PrivateMode.MOUSE_SGR_MODE,
        ]
        if self.modes.bracketed_paste is None:
            modes.append(escape.PrivateMode.BRACKETED_PASTE)
        if self.modes.focus_reporting is None:
            modes.append(escape.PrivateMode.FOCUS_REPORTING)

        # a late reply to a query of an earlier start describes the same terminal, so it may answer the new query
        self._mode_queries_pending = set(modes)
        queries = "".join(mode.query for mode in modes)
        if self.extended_keys and self.modes.kitty_keyboard is None and not self._keyboard_query_pending:
            # A terminal ignores a query it does not know, and answers Primary DA in the order it reads the queries,
            # so a protocol that has no reply by the time the Primary DA reply arrives is not supported.
            queries += escape.KITTY_KEYBOARD_QUERY + escape.MODIFY_OTHER_KEYS_QUERY + escape.REPORT_DEVICE_ATTRIBUTES
            self._keyboard_query_pending = True
        self.write(queries)
        self.flush()

    def _apply_terminal_reports(
        self,
        decoded_codes: _DecodedInputWithReports,
    ) -> _DecodedInput:
        """Apply the query replies among *decoded_codes* to `self.modes` and strip them out.

        A reply counts only as the answer to a query urwid sent and has no answer for yet.
        Any other reply is dropped without effect, so input that only looks like a reply cannot change the modes.

        - A private mode report counts once for each mode queried.
        - A keyboard protocol reply counts between the keyboard protocol queries and the Primary DA reply sent
          after them.
        """
        logger = self.logger.getChild("terminal_reports")
        filtered: _DecodedInput = []
        reports: list[tuple[str, int]] = []
        for item in decoded_codes:
            match item:
                case ("private mode report", str() as mode, int() as value) if mode in self._mode_queries_pending:
                    self._mode_queries_pending.discard(mode)
                    reports.append((mode, value))
                case ("private mode report", *_):
                    logger.debug(f"Dropped a reply to a query urwid has no answer pending for: {item!r}")
                case ("keyboard protocol report" | "modify keys report" | "device attributes", *_) if (
                    not self._keyboard_query_pending
                ):
                    logger.debug(f"Dropped a reply to a query urwid has no answer pending for: {item!r}")
                case ("keyboard protocol report", _flags):
                    self.modes.kitty_keyboard = True
                case ("modify keys report", escape.MODIFY_OTHER_KEYS_RESOURCE, value):
                    self.modes.modify_other_keys = True
                    self._modify_other_keys_reported = value
                case ("modify keys report", *_):
                    pass  # another key modifier resource, which urwid did not query
                case ("device attributes", _attributes):
                    # the Primary DA reply that ends the answers to the keyboard protocol queries
                    self._keyboard_query_pending = False
                    self.modes.kitty_keyboard = bool(self.modes.kitty_keyboard)
                    self.modes.modify_other_keys = bool(self.modes.modify_other_keys)
                    self._enable_keyboard_protocol()
                case _:
                    filtered.append(item)

        if reports:
            enable = [
                code
                for field in self.modes.set_from_codes(*reports)
                if (code := self._PRIVATE_MODE_ENABLE_SEQUENCE.get(field, ""))
            ]
            if enable:
                self.write("".join(enable))
                self.flush()

        return filtered

    def _enable_keyboard_protocol(self) -> None:
        """Turn on the keyboard protocol the terminal answered for, preferring kitty's to modifyOtherKeys.

        Only for ``extended_keys``, and once per start of the screen: the kitty flags are pushed on the stack of the
        screen in use, so they are popped before the alternate screen is left (see `_disable_keyboard_protocol()`).
        """
        if not self.extended_keys or not self._started or self._keyboard_protocol_enabled is not None:
            return
        if self.modes.kitty_keyboard:
            self.write(escape.KITTY_KEYBOARD_PUSH)
            self._keyboard_protocol_enabled = "kitty"
        elif self.modes.modify_other_keys:
            self.write(escape.MODIFY_OTHER_KEYS_ON)
            self._keyboard_protocol_enabled = "modify other keys"
        else:
            return
        self.flush()

    def _disable_keyboard_protocol(self) -> None:
        """Restore the keyboard protocol state `_enable_keyboard_protocol()` changed, as the screen stops.

        Replies not read by then can be lost, as a POSIX stop discards the pending input, so queries still waiting for
        them are sent again on the next start.
        """
        if self._keyboard_protocol_enabled == "kitty":
            self.write(escape.KITTY_KEYBOARD_POP)
        elif self._keyboard_protocol_enabled == "modify other keys":
            self.write(escape.set_modify_other_keys(self._modify_other_keys_reported))
        self._keyboard_protocol_enabled = None
        self._keyboard_query_pending = False

    def _drop_past_end_mouse_events(self, codes: _DecodedInput) -> _DecodedInput:
        """Drop the mouse events at a position an X10 report cannot carry, when the terminal has no SGR reports.

        Without SGR reports every mouse report is in the X10 encoding, and xterm sends a column or row past its limit
        as a NUL byte. That byte decodes as the limit itself, so the event would arrive at a wrong position.
        A release is kept, since it ends a press or a drag the application tracks.
        """
        if self.modes.mouse_sgr_mode is not False:
            return codes
        return [
            code
            for code in codes
            if not (
                isinstance(code, tuple)
                and len(code) == 4
                and escape.MOUSE_X10_PAST_END in code[2:]
                # a release ends a press or a drag the application tracks, wherever it happens
                and not code[0].endswith("mouse release")
            )
        ]

    @abc.abstractmethod
    def _start(  # pylint: disable=keyword-arg-before-vararg
        self,
        alternate_buffer: bool = True,
        *args: typing.Any,
        **kwargs: typing.Any,
    ) -> None:
        """
        Initialize the screen and input mode.

        :param alternate_buffer: use alternate screen buffer
        :param args: not supported; an implementation raises :exc:`TypeError` when any is given.
        :param kwargs: not supported; an implementation raises :exc:`TypeError` when any is given.
        """

    def _stop_mouse_restore_buffer(self) -> None:
        """Stop mouse tracking and restore the screen."""
        # Keep the state the application requested: _start() restores it on a restart.
        mouse_tracking_requested = self._mouse_tracking_enabled
        try:
            self._mouse_tracking(False)
        finally:
            self._mouse_tracking_enabled = mouse_tracking_requested

        move_cursor = "" if self.maxrow is None else escape.set_cursor_position(0, self.maxrow)
        if self._alternate_buffer:
            # Below the last frame first: the move lands on its last row and the line feed goes past it.
            # A terminal without an alternate screen drew the frames on its main screen and ignores the switch back,
            # and one with it scrolls only the alternate screen and restores the cursor saved by the switch.
            if move_cursor:
                move_cursor += "\n"
            move_cursor += escape.PrivateMode.ALTERNATE_SCREEN_BUFFER.disable_seq
        # an application's own "U" run, or a partly written frame, can leave a hyperlink open
        close = escape.HYPERLINK_CLOSE if self.hyperlinks else ""
        self.write(close + self._attrspec_to_escape(AttrSpec("", "")) + escape.SI + move_cursor + escape.SHOW_CURSOR)
        self.flush()
        # leaving the alternate screen restores the G1 the terminal had before, and whatever runs before the next
        # start can reset the character sets, so G1 is designated again then
        self._setup_G1_done = False

    def _stop_restore_palette(self) -> None:
        """Reset any palette entries modify_terminal_palette() changed this session.

        The entries go back to the terminal's default, not to what they were before the screen started.
        OSC 104 resets the changed entries only.
        The Linux console can only reset all 16 entries at once.
        Its reset sequence has no terminator, so a terminal that only claims ``TERM=linux`` reads it as an
        unterminated OSC string: call this before other escape sequences are written, which end that string.
        """
        if not self._modified_palette_entries:
            return
        if _is_linux_console(self.term):
            self.write(escape.LINUX_RESET_PALETTE)
            self.flush()
            self._modified_palette_entries.clear()
            return
        if self.term == "fbterm":
            # fbterm's palette-modification escape (used in modify_terminal_palette) has no
            # known reset counterpart, so there is nothing safe to send here.
            self._modified_palette_entries.clear()
            return

        indexes = ";".join(str(index) for index in sorted(self._modified_palette_entries))
        self.write(f"{escape.OSC}104;{indexes}{escape.ST}")
        self.flush()
        self._modified_palette_entries.clear()

    def set_title(self, title: str | None) -> None:
        """Set the window title of the terminal.

        The title is shown while the screen runs.
        One set before :meth:`start` is shown when the screen starts.
        Each start saves the title the terminal had, and stopping the screen gives it back,
        so the shell's title is back while :meth:`MainLoop.paused` runs another program.

        Control characters are removed from *title*: a title built from data could otherwise end the title
        and send the rest of the text as terminal commands.
        Characters the terminal encoding cannot represent are replaced with ``?``.
        So are characters a single-byte encoding writes with a byte from 0x80 to 0x9f,
        which a terminal can read as C1 controls.

        The previous title is saved on the terminal's title stack (xterm ``XTWINOPS`` 22 and 23).
        A terminal without the stack ignores it, and keeps the application's title after the screen stops.
        On a Windows console the title is set and saved through the console API instead.
        Nothing is sent to the Linux virtual console or fbterm, which have no window title.
        Nothing is sent to a ``dumb`` terminal outside Windows either, which would print the title as text.

        :param title: the new window title, or None to give the terminal back the title it had before.
        """
        self._title = None if title is None else _TITLE_CONTROLS.sub("", title)
        if self._started:
            self._show_title()

    def _show_title(self) -> None:
        """Show the title :meth:`set_title` asked for, saving the terminal's own title first."""
        if self._title is None:
            self._restore_title()
            return
        if _rejects_osc(self.term):
            return
        if not self._title_saved:
            self._save_title()
            self._title_saved = True
        self._write_title(self._title)
        self.flush()

    def _restore_title(self) -> None:
        """Give the terminal back the title it had before :meth:`_show_title` saved it."""
        if not self._title_saved:
            return
        self._title_saved = False
        self._restore_saved_title()
        self.flush()

    def _save_title(self) -> None:
        """Save the terminal's current window title; :meth:`_restore_saved_title` gives it back."""
        self.write(escape.TITLE_PUSH)

    def _restore_saved_title(self) -> None:
        """Give the terminal back the window title :meth:`_save_title` saved."""
        self.write(escape.TITLE_POP)

    def _write_title(self, title: str) -> None:
        """Write *title*, which has no control characters, as the terminal's window title."""
        encoding = util.get_encoding()
        if util.get_encoding_mode() == "narrow":
            title = "".join("?" if _C1_BYTES.search(char.encode(encoding, "replace")) else char for char in title)
        self.write(f"{escape.SET_TITLE}{title.encode(encoding, 'replace').decode(encoding)}{escape.BEL}")

    def copy_to_clipboard(self, text: str) -> None:
        """Copy text to the system clipboard through the terminal.

        The text is sent as UTF-8 in base64 inside OSC 52,
        so no character of it can reach the terminal as a command.
        A lone surrogate, as in a file name that did not decode, is sent as ``?``.
        The sequence travels with the screen output, so it also reaches the user's terminal over SSH.
        What happens next is up to the terminal:

        - many terminal emulators copy the text;
        - some ask the user first, or copy only after the feature is turned on in their settings;
        - tmux passes the text on with its ``set-clipboard`` option on;
        - a terminal without OSC 52 ignores the sequence.

        No reply tells the application which case it was.
        Terminals and multiplexers also drop a sequence longer than their own limit, so a long text may not arrive.
        The whole text is written at once, and a long one holds up the main loop until the terminal has read it.

        Nothing is sent to the Linux virtual console or fbterm, which have no clipboard.
        Nothing is sent to a ``dumb`` terminal outside Windows either, which would print the sequence as text.

        :param text: the text to copy.
        :raises RuntimeError: the screen is not running.
            A console that reads escape sequences only while the screen runs, such as the Windows console,
            would print the sequence as text.
        """
        if not self._started:
            raise RuntimeError("Start the screen before copying to the clipboard")
        if _rejects_osc(self.term):
            return
        data = base64.b64encode(text.encode("utf-8", "replace")).decode("ascii")
        self.write(f"{escape.SET_CLIPBOARD}{data}{escape.BEL}")
        self.flush()

    @abc.abstractmethod
    def _stop(self) -> None:
        """Restore the screen."""

    def write(self, data: str) -> None:
        """Write some data to the terminal.

        You may wish to override this if you're using something other than
        regular files for input and output.
        """
        self._term_output_file.write(data)

    def flush(self) -> None:
        """Flush the output buffer.

        You may wish to override this if you're using something other than
        regular files for input and output.
        """
        self._term_output_file.flush()

    @typing.overload
    def get_input(self, raw_keys: Literal[False]) -> _DecodedInput: ...

    @typing.overload
    def get_input(self, raw_keys: Literal[True]) -> tuple[_DecodedInput, list[int]]: ...

    def get_input(self, raw_keys: bool = False) -> _DecodedInput | tuple[_DecodedInput, list[int]]:
        r"""Return pending input as a list.

        :param raw_keys: return raw keycodes as well as translated versions
        :raises RuntimeError: the screen has not been started.
        :raises InputClosedError: the input reached end of file.

        This function will immediately return all the input since the
        last time it was called.  If there is no input pending it will
        wait before returning an empty list.  The wait time may be
        configured with the set_input_timeouts function.

        If raw_keys is False (default) this function will return a list
        of keys pressed.  If raw_keys is True this function will return
        a ( keys pressed, raw keycodes ) tuple instead.

        Examples of keys returned:

        * ASCII printable characters:  :kbd:`space`, :kbd:`a`, :kbd:`0`, :kbd:`A`, :kbd:`-`, :kbd:`/`
        * ASCII control characters:  :kbd:`tab`, :kbd:`enter`
        * Escape sequences:  :kbd:`up`, :kbd:`page up`, :kbd:`home`, :kbd:`insert`, :kbd:`f1`
        * Key combinations:  :kbd:`shift f1`, :kbd:`meta a`, :kbd:`ctrl b`
        * Window events:  ``"window resize"``

        Other characters, decoded from the terminal encoding (UTF-8, or a single- or double-byte encoding):

        * Unicode characters: "\u00a5", "\u253c", "\u4e2d"

        Examples of mouse events returned:

        * Mouse button press: ('mouse press', 1, 15, 13),
                              ('meta mouse press', 2, 17, 23)
        * Mouse drag: ('mouse drag', 1, 16, 13),
                      ('mouse drag', 1, 17, 13),
                      ('ctrl mouse drag', 1, 18, 13)
        * Mouse button release: ('mouse release', 0, 18, 13),
                                ('ctrl mouse release', 0, 17, 23)

        The button number is a :class:`~urwid.MouseButton` value.
        """
        logger = self.logger.getChild("get_input")
        if not self._started:
            raise RuntimeError

        self._wait_for_input_ready(self._next_timeout)
        keys, raw = self.parse_input(None, None, self.get_available_raw_input())

        # Avoid pegging CPU at 100% when slowly resizing
        if keys == ["window resize"] and self.prev_input_resize:
            logger.debug('get_input: got "window resize" > 1 times. Enable throttling for resize.')
            for _ in range(2):
                self._wait_for_input_ready(self.resize_wait)
                new_keys, new_raw = self.parse_input(None, None, self.get_available_raw_input())
                raw += new_raw
                if new_keys and new_keys != ["window resize"]:
                    if "window resize" in new_keys:
                        keys = new_keys
                    else:
                        keys.extend(new_keys)
                    break

        if keys == ["window resize"]:
            self.prev_input_resize = 2
        elif self.prev_input_resize == 2 and not keys:
            self.prev_input_resize = 1
        else:
            self.prev_input_resize = 0

        if raw_keys:
            return keys, raw
        return keys

    def get_input_descriptors(self) -> list[SupportsFileno | int]:
        """Return a list of integer file descriptors that should be polled in external event loops.

        Used to check for user input. Use this method if you are implementing your own event loop.

        This method is only called by `hook_event_loop`, so if you override
        that, you can safely ignore this.
        """
        if not self._started:
            return []

        fd_list: list[SupportsFileno | int] = [self._resize_pipe_rd]

        if (input_io := self._term_input_io) is not None:
            fd_list.append(input_io)
        return fd_list

    _current_event_loop_handles: Sequence[typing.Any] = ()

    @abc.abstractmethod
    def unhook_event_loop(self, event_loop: EventLoop) -> None:
        """Remove any hooks added by hook_event_loop."""

    @abc.abstractmethod
    def hook_event_loop(
        self,
        event_loop: EventLoop,
        callback: Callable[[_DecodedInput, list[int]], typing.Any],
    ) -> None:
        """Register the given callback with the event loop, to be called with new input whenever it's available.

        The callback should be passed a list of processed keys and a list of unprocessed keycodes.

        Subclasses may wish to use parse_input to wrap the callback.

        .. deprecated:: 5.0
            A subclass that defines ``get_input_nonblocking()`` is still polled through it.
            Override :meth:`get_available_raw_input` instead. This API will be removed in version 7.0.
        """

    _input_timeout: typing.Any = None

    def _make_legacy_input_wrapper(
        self,
        event_loop: EventLoop,
        callback: Callable[[_DecodedInput, list[int]], typing.Any],
    ) -> Callable[[], None]:
        """Support old Screen classes that still have a get_input_nonblocking and expect it to work.

        :warns DeprecationWarning: always, since overriding ``get_input_nonblocking()`` is deprecated.
        """
        _deprecation.warn(
            f"{self.__class__.__module__}.{self.__class__.__qualname__} defines get_input_nonblocking(). "
            "Override get_available_raw_input() instead.",
            since="5.0",
            removed_in="7.0",
        )

        @functools.wraps(callback)
        def wrapper() -> None:
            if self._input_timeout:
                event_loop.remove_alarm(self._input_timeout)
                self._input_timeout = None

            timeout, keys, raw = self.get_input_nonblocking()  # type: ignore[attr-defined]  # pylint: disable=no-member
            if timeout is not None:
                self._input_timeout = event_loop.alarm(timeout, wrapper)

            callback(keys, raw)

        return wrapper

    def _get_input_codes(self) -> list[int]:
        return list(self._get_keyboard_codes())

    def get_available_raw_input(self) -> list[int]:
        """
        Return any currently available input. Does not block.

        This method is only used by the default `hook_event_loop`
        implementation; you can safely ignore it if you implement your own.

        :raises InputClosedError: the input reached end of file.
        """
        logger = self.logger.getChild("get_available_raw_input")
        codes = [*self._partial_codes, *self._get_input_codes()]
        self._partial_codes = []

        # clean out the pipe used to signal external event loops
        # that a resize has occurred
        with selectors.DefaultSelector() as selector:
            selector.register(self._resize_pipe_rd, selectors.EVENT_READ)
            present_resize_flag = selector.select(0)  # nonblocking
            while present_resize_flag:
                logger.debug("Resize signal received. Cleaning socket.")
                # Argument "size" is maximum buffer size to read. Since we're emptying, set it reasonably big.
                self._resize_pipe_rd.recv(128)
                present_resize_flag = selector.select(0)

        return codes

    @typing.overload
    def parse_input(
        self,
        event_loop: EventLoop | None,
        callback: None,
        codes: list[int],
        wait_for_more: bool = ...,
    ) -> tuple[_DecodedInput, list[int]]: ...

    @typing.overload
    def parse_input(
        self,
        event_loop: EventLoop | None,
        callback: Callable[[_DecodedInput, list[int]], typing.Any],
        codes: list[int],
        wait_for_more: bool = ...,
    ) -> None: ...

    def parse_input(
        self,
        event_loop: EventLoop | None,
        callback: Callable[[_DecodedInput, list[int]], typing.Any] | None,
        codes: list[int],
        wait_for_more: bool = True,
    ) -> tuple[_DecodedInput, list[int]] | None:
        """
        Read any available input from get_available_raw_input, parses it into keys, and calls the given callback.

        The current implementation tries to avoid any assumptions about what
        the screen or event loop look like; it only deals with parsing keycodes
        and setting a timeout when an incomplete one is detected.

        `codes` is a list of keycodes: the integer values of the input bytes, or curses key codes.
        """
        logger = self.logger.getChild("parse_input")

        # Note: event_loop may be None for 100% synchronous support, only used
        # by get_input.  Not documented because you shouldn't be doing it.
        if self._input_timeout and event_loop:
            event_loop.remove_alarm(self._input_timeout)
            self._input_timeout = None

        original_codes = codes
        decoded_codes: _DecodedInputWithReports = []
        try:
            while codes:
                run, remaining_codes = escape.process_keyqueue(
                    codes, wait_for_more, keyboard_protocol=self._keyboard_protocol_enabled
                )
                codes = remaining_codes.copy()
                decoded_codes.extend(run)
        except escape.MoreInputRequired:
            # Set a timer to wait for the rest of the input; if it goes off
            # without any new input having come in, use the partial input
            k = len(original_codes) - len(codes)
            raw_codes = original_codes[:k]
            self._partial_codes = codes

            def _parse_incomplete_input() -> None:
                self._input_timeout = None
                self._partial_codes = []
                self.parse_input(event_loop, callback, codes, wait_for_more=False)

            if event_loop:
                self._input_timeout = event_loop.alarm(self.complete_wait, _parse_incomplete_input)

        else:
            raw_codes = original_codes
            self._partial_codes = []

        output_codes = self._drop_past_end_mouse_events(self._apply_terminal_reports(decoded_codes))

        logger.debug(f"Decoded codes: {output_codes!r}, raw codes: {raw_codes!r}")

        if self._resized:
            self._resized = False
            self.screen_buf = None
            output_codes.append("window resize")
            logger.debug('Added "window resize" to the codes')

        if callback:
            callback(output_codes, raw_codes)
            return None

        # For get_input
        return output_codes, raw_codes

    def _wait_for_input_ready(self, timeout: float | None) -> list[int]:
        logger = self.logger.getChild("wait_for_input_ready")
        fd_list = self.get_input_descriptors()

        logger.debug(f"Waiting for input: descriptors={fd_list!r}, timeout={timeout!r}")
        with read_selector((fd, None) for fd in fd_list) as selector:
            ready = selector.select(timeout)

        logger.debug(f"Input ready: {ready}")

        return [event.fd for event, _ in ready]

    @abc.abstractmethod
    def _read_raw_input(self, timeout: float) -> Iterable[int]: ...

    def _get_keyboard_codes(self) -> Iterable[int]:
        return self._read_raw_input(0)

    def _setup_G1(self) -> None:
        """Initialize the G1 character set to graphics mode if required.

        :raises OSError: the terminal could not be written to. The setup is tried again on the next draw.
        """
        if self._setup_G1_done:
            return

        self.write(escape.DESIGNATE_G1_SPECIAL)
        self.flush()
        self._setup_G1_done = True

    def draw_screen(self, size: tuple[int, int], canvas: Canvas) -> None:
        """Paint screen with rendered canvas.

        :raises RuntimeError: the screen has not been started.
        :raises ValueError: *canvas* does not have the number of rows given by *size*.
        :raises OSError: the terminal could not be written to, for a reason other than an interrupted system call.
        """

        def set_cursor_position(x: int, y: int) -> str:
            if self._rows_used is None:
                return escape.set_cursor_position(x, y)
            if cy > y:
                return "\b" + escape.CURSOR_HOME_COL + escape.move_cursor_up(cy - y) + escape.move_cursor_right(x)
            return "\b" + escape.CURSOR_HOME_COL + escape.move_cursor_down(y - cy) + escape.move_cursor_right(x)

        def handle_row(
            attr: Hashable,
            charset: Literal["0", "U"] | None,
            run: bytes,
            last: bool,
        ) -> None:
            """Append the escape sequences and text of one canvas run to the output.

            The bytes of a charset "U" run are written unchanged, OSC 8 sequences included:
            they belong to the application, and urwid's own hyperlinks only wrap attribute-linked runs.

            :raises TypeError: *run* is not a byte string.
            :raises ValueError: *charset* is not a known character set flag.
            """
            nonlocal last_charset_flag, last_attributes, first, link_open  # type: ignore[misc]

            if not isinstance(run, bytes):  # canvases render with bytes
                raise TypeError(run)

            if charset != "U":
                run = run.translate(UNPRINTABLE_TRANS_TABLE)

            if last_attributes != attr:
                attr_escape = self._attr_to_escape(attr)
                if self.hyperlinks:
                    # only an escape that opens a hyperlink ends with ST, and an open replaces any open link
                    opens = attr_escape.endswith(escape.ST)
                    if link_open and not opens:
                        output.append(escape.HYPERLINK_CLOSE)
                    link_open = opens
                output.append(attr_escape)
                last_attributes = attr

            if last:
                output.append("\x08" * back)

            if encoding != "utf-8" and (first or last_charset_flag != charset):
                if charset not in {None, "0", "U"}:
                    raise ValueError(charset)
                if last_charset_flag == "U":
                    output.append(escape.IBMPC_OFF)

                if charset is None:
                    icss = escape.SI
                elif charset == "U":
                    icss = escape.IBMPC_ON
                else:
                    icss = escape.SO

                output.append(icss)

                last_charset_flag = charset

            line_text = run.decode(encoding, "replace")
            if charset != "U" and not line_text.isascii():
                line_text = line_text.translate(UNPRINTABLE_C1_TRANS_TABLE)

            if not last:
                output.append(line_text)
            else:
                if not IS_WINDOWS:
                    output.extend((escape.INSERT_ON, line_text, escape.INSERT_OFF))
                else:
                    output.extend((f"{escape.CSI}{str_util.calc_width(line_text, 0, len(line_text))}@", line_text))

                if encoding != "utf-8" and charset == "U":
                    output.append(escape.IBMPC_OFF)

            if self.hyperlinks and charset == "U":
                # the run may have closed or replaced urwid's hyperlink, so the next run reopens its own
                last_attributes = link_closed

            first = False

        encoding = util.get_encoding()

        logger = self.logger.getChild("draw_screen")

        (maxcol, maxrow) = size

        if not self._started:
            raise RuntimeError

        if maxrow != canvas.rows():
            raise ValueError(maxrow)

        # quick return if nothing has changed
        if self.screen_buf and canvas is self._screen_buf_canvas:
            return

        self._setup_G1()

        if self._resized:
            # handle resize before trying to draw screen
            logger.debug("Not drawing screen: screen resized and resize was not handled")
            return

        logger.debug(f"Drawing screen with size {size!r}")

        last_attributes: Hashable = None  # Default = empty
        # last_attributes after a hyperlink is closed: unequal to every attribute, so the next run reopens its link
        link_closed = object()
        # whether the output has a hyperlink open that urwid opened
        link_open = False

        output: list[str] = [escape.HIDE_CURSOR, self._attr_to_escape(last_attributes)]

        if self._rows_used is None:
            output.append(escape.CURSOR_HOME)

        osb: list[list[tuple[str, Literal["0", "U"] | None, bytes]]] = self._drawn_rows if self.screen_buf else []
        sb: list[list[tuple[Hashable, Literal["0", "U"] | None, bytes]]] = []
        drawn_rows: list[list[tuple[str, Literal["0", "U"] | None, bytes]]] = []
        cy = self._cy
        y = -1

        ins: list[tuple[Hashable, Literal["0", "U"] | None, bytes]] = []
        if self._rows_used is None:
            output.append(escape.set_cursor_position(0, 0))
        else:
            output.append(escape.CURSOR_HOME_COL + escape.move_cursor_up(cy))
        cy = 0

        first = True
        last_charset_flag: Literal["0", "U"] | None = None

        for row in canvas.content():
            y += 1
            drawn_row: list[tuple[str, Literal["0", "U"] | None, bytes]] = [
                (self._attr_to_escape(a), cs, run) for a, cs, run in row
            ]
            sb.append(row)
            drawn_rows.append(drawn_row)
            if osb and y < len(osb) and osb[y] == drawn_row:
                # this row of the screen buffer matches what is
                # currently displayed, so we can skip this line
                continue

            # leave blank lines off display when we are using
            # the default screen buffer (allows partial screen)
            if self._rows_used is not None and y > self._rows_used:
                if len(row) == 1 and not row[0][2].strip():
                    continue
                self._rows_used = y

            if y or self._rows_used is not None:
                output.append(set_cursor_position(0, y))
            # after updating the line we will be just over the
            # edge, but terminals still treat this as being
            # on the same line
            cy = y

            whitespace_at_end = False
            back = 0

            if row:
                a, cs, run = row[-1]
                if (
                    run[-1:] == b" "
                    and self.back_color_erase
                    and not (
                        (pal_a := self.resolve_attr(a, _ATTRSPEC_INDEX_BY_COLORS[self.colors])).standout
                        or pal_a.underline
                        or (self.hyperlinks and pal_a.hyperlink is not None and pal_a.hyperlink.uri)
                    )
                ):
                    whitespace_at_end = True
                    row = [*row[:-1], (a, cs, run.rstrip(b" "))]  # noqa: PLW2901
                elif y == maxrow - 1 and maxcol > 1:
                    row, back, ins = self._last_row(row)  # noqa: PLW2901
            else:
                continue

            for a, cs, run in row:
                handle_row(a, cs, run, last=False)

            if ins:
                a, cs, run = ins[0]
                handle_row(a, cs, run, last=True)
                # runs of no width between Y and Z follow Y, and add nothing to shift
                for a, cs, run in ins[1:]:
                    handle_row(a, cs, run, last=False)

            if link_open:
                # a hyperlink left open would cover the cursor moves and erased cells up to the next run
                output.append(escape.HYPERLINK_CLOSE)
                link_open = False
                last_attributes = link_closed

            if whitespace_at_end:
                output.append(escape.ERASE_IN_LINE_RIGHT)

        if canvas.cursor is not None:
            x, y = canvas.cursor
            output += [set_cursor_position(x, y), escape.SHOW_CURSOR]
            self._cy = y

        if self._resized:
            # handle resize before trying to draw screen
            return
        try:
            # A single write() call, rather than one per output fragment, avoids paying the
            # per-call overhead (and, for a real file, a separate write syscall) once per row.
            frame = "".join(output)
            if self.modes.synchronized_output:
                # Confirmed supported; the terminal defers painting until END_SYNCHRONIZED_UPDATE.
                frame = (
                    f"{escape.PrivateMode.SYNCHRONIZED_OUTPUT.enable_seq}"
                    f"{frame}"
                    f"{escape.PrivateMode.SYNCHRONIZED_OUTPUT.disable_seq}"
                )
            self.write(frame)
            self.flush()
        except OSError as e:
            # ignore interrupted syscall
            if e.args[0] != errno.EINTR:
                raise

        self.screen_buf = sb
        self._drawn_rows = drawn_rows
        self._screen_buf_canvas = canvas

    def _last_row(
        self,
        row: list[tuple[Hashable, Literal["0", "U"] | None, bytes]],
    ) -> tuple[
        list[tuple[Hashable, Literal["0", "U"] | None, bytes]],
        int,
        list[tuple[Hashable, Literal["0", "U"] | None, bytes]],
    ]:
        """On the last row we need to slide the bottom right character into place.

        eg. last row:
        XXXXXXXXXXXXXXXXXXXXYZ

        Y will be drawn after Z, shifting Z into position.

        Runs of no width, such as a bidi mark or a combining mark, are neither Y nor Z:
        those after Z are drawn after Z, and those between Y and Z are written after Y
        is inserted, so each stays behind the character it follows.

        The row is returned untouched, with nothing to insert and its bottom right
        character written directly, when:

        - nothing of any width comes before Z, as happens with a double width
          character on a two column screen, so there is no Y to draw after Z;
        - a non-empty run of no width in charset "U" comes after Y;
        - Y or Z is taken from a charset "U" run holding the start of a raw sequence.

        A charset "U" run holds the application's raw bytes. The column count can read
        the parameters of an escape sequence there as text and cut it, and the sequence,
        such as an OSC 8 hyperlink, applies to what is written after it, so moving it
        around Y would change what it applies to.

        :returns: the row to draw, the columns to move back over Z, and the runs to insert, Y first.
        """
        end = len(row)
        while end > 1 and not str_util.calc_width(row[end - 1][2], 0, len(row[end - 1][2])):
            end -= 1
        tail = row[end:]

        raw_sequence = _RAW_SEQUENCE_UTF8 if str_util.get_byte_encoding() == "utf8" else _RAW_SEQUENCE_BYTES
        z_attr, z_cs, last_text = row[end - 1]
        if z_cs == "U" and raw_sequence.search(last_text):
            return row, 0, []
        last_cols = str_util.calc_width(last_text, 0, len(last_text))
        last_offs, _ = str_util.calc_text_pos(last_text, 0, len(last_text), last_cols - 1)
        z_text = last_text[last_offs:]
        head = row[: end - 1]
        if last_offs:
            head.append((z_attr, z_cs, last_text[:last_offs]))

        y_end = len(head)
        while y_end and not str_util.calc_width(head[y_end - 1][2], 0, len(head[y_end - 1][2])):
            y_end -= 1
        if not y_end or any(cs == "U" and run for _, cs, run in (*head[y_end:], *tail)):
            return row, 0, []

        y_attr, y_cs, y_run = head[y_end - 1]
        if y_cs == "U" and raw_sequence.search(y_run):
            return row, 0, []
        y_cols = str_util.calc_width(y_run, 0, len(y_run))
        y_offs, _ = str_util.calc_text_pos(y_run, 0, len(y_run), y_cols - 1)
        new_row = head[: y_end - 1]
        if y_offs:
            new_row.append((y_attr, y_cs, y_run[:y_offs]))
        new_row.append((z_attr, z_cs, z_text))
        new_row.extend(tail)
        # Z is drawn where Y starts, so move back over Z to insert Y in front of it
        return new_row, str_util.calc_width(z_text, 0, len(z_text)), [(y_attr, y_cs, y_run[y_offs:]), *head[y_end:]]

    def clear(self) -> None:
        """Force the screen to be completely repainted on the next call to draw_screen()."""
        self.screen_buf = None

    def _attr_to_escape(self, a: Hashable) -> str:
        """Convert canvas run attribute a to an escape sequence for the terminal.

        With :attr:`hyperlinks` on, the escape of an attribute with a hyperlink ends with the OSC 8 sequence opening it.
        """
        if found := self._pal_escape.get(a):
            return found
        spec = self.resolve_attr(a, _ATTRSPEC_INDEX_BY_COLORS[self.colors])
        found = self._attrspec_to_escape(spec)
        if self.hyperlinks and spec.hyperlink is not None and spec.hyperlink.uri:
            found += escape.hyperlink_open(spec.hyperlink)
        if len(self._pal_escape) >= _RESOLVED_ATTRS_LIMIT:
            self._pal_escape.clear()
        self._pal_escape[a] = found
        return found

    def _attrspec_to_escape(self, a: AttrSpec) -> str:
        r"""Convert AttrSpec instance a to an escape sequence for the terminal.

        >>> from urwid.display.raw import Screen  # this class is abstract
        >>> s = Screen()
        >>> s.set_terminal_properties(colors=256)
        >>> a2e = s._attrspec_to_escape
        >>> a2e(s.AttrSpec("brown", "dark green"))
        '\x1b[0;33;42m'
        >>> a2e(s.AttrSpec("#fea,underline", "#d0d"))
        '\x1b[0;38;5;229;4;48;5;164m'
        """
        st = (
            "1;" * a.bold
            + "2;" * a.faint
            + "3;" * a.italics
            + "4;" * a.underline
            + "5;" * a.blink
            + "7;" * a.standout
            + "9;" * a.strikethrough
        )
        if self.term == "fbterm":
            # fbterm takes a palette color from its own sequences, after SGR for the default colors and the settings;
            # an unset color has no palette entry, as entry 0 is black. Its 39 also ends underline, so it comes first.
            escapes = f"{escape.CSI}0;39;49;{st}".removesuffix(";") + "m"
            if a.foreground_basic or a.foreground_high:
                escapes += f"{escape.CSI}1;{a.foreground_number:d}}}"
            if a.background_basic or a.background_high:
                escapes += f"{escape.CSI}2;{a.background_number:d}}}"
            return escapes

        if a.foreground_true:
            fg = f"38;2;{';'.join(str(part) for part in a.get_rgb_values()[0:3])}"
        elif a.foreground_high:
            fg = f"38;5;{a.foreground_number:d}"
        elif a.foreground_basic:
            if a.foreground_number > 7:
                if self.fg_bright_is_bold:
                    fg = f"1;{a.foreground_number - _SGR_BRIGHT_OFFSET + _SGR_FG_BASE:d}"
                else:
                    fg = f"{a.foreground_number - _SGR_BRIGHT_OFFSET + _SGR_FG_BRIGHT_BASE:d}"
            else:
                fg = f"{a.foreground_number + _SGR_FG_BASE:d}"
        else:
            fg = "39"
        if a.background_true:
            bg = f"48;2;{';'.join(str(part) for part in a.get_rgb_values()[3:6])}"
        elif a.background_high:
            bg = f"48;5;{a.background_number:d}"
        elif a.background_basic:
            if a.background_number > 7:
                if self.bg_bright_is_blink:
                    bg = f"5;{a.background_number - _SGR_BRIGHT_OFFSET + _SGR_BG_BASE:d}"
                else:
                    # this doesn't work on most terminals
                    bg = f"{a.background_number - _SGR_BRIGHT_OFFSET + _SGR_BG_BRIGHT_BASE:d}"
            else:
                bg = f"{a.background_number + _SGR_BG_BASE:d}"
        else:
            bg = "49"
        return f"{escape.CSI}0;{fg};{st}{bg}m"

    def set_terminal_properties(
        self,
        colors: Literal[1, 16, 88, 256, 16777216] | None = None,
        bright_is_bold: bool | None = None,
        has_underline: bool | None = None,
        hyperlinks: bool | None = None,
    ) -> None:
        """Set the terminal's color and attribute-rendering properties.

        :param colors: number of colors terminal supports (1, 16, 88, 256, or 2**24) or None to leave unchanged
        :param bright_is_bold: set to True if this terminal uses the bold setting to create bright colors (numbers
            8-15), set to False if this Terminal can create bright colors without bold or None to leave unchanged
        :param has_underline: set to True if this terminal can use the underline setting, False if it cannot or None to
            leave unchanged
        :param hyperlinks: set to True to draw the hyperlinks of display attributes as OSC 8 links,
            False to draw them as plain text, or None to leave unchanged.
            Off by default: no query for OSC 8 support exists, so applications that know their terminal set it.
        """
        if colors is None:
            colors = self.colors
        if bright_is_bold is None:
            bright_is_bold = self.fg_bright_is_bold
        if has_underline is None:
            has_underline = self.has_underline
        if hyperlinks is None:
            hyperlinks = self.hyperlinks

        if (
            colors == self.colors
            and bright_is_bold == self.fg_bright_is_bold
            and has_underline == self.has_underline
            and hyperlinks == self.hyperlinks
        ):
            return

        self.colors = colors
        self.fg_bright_is_bold = bright_is_bold
        self.has_underline = has_underline
        self.hyperlinks = hyperlinks

        self.clear()
        self._pal_escape.clear()

    def reset_default_terminal_palette(self) -> None:
        """Attempt to set the terminal palette to default values as taken from xterm.

        Uses a number of colors from the current set_terminal_properties() screen setting.
        """
        if self.colors == 1:
            return
        if self.colors == 2**24:
            colors = 256
        else:
            colors = self.colors

        values = _COLOR_VALUES_88 if colors == 88 else _COLOR_VALUES_256
        entries = [(n, *values[n]) for n in range(min(colors, 256))]
        self.modify_terminal_palette(entries)

    def modify_terminal_palette(self, entries: Iterable[tuple[int, int, int, int]]) -> None:
        """Attempt to set part of the terminal palette; this does not work on all terminals.

        The changes are sent as a single escape sequence so they should all take effect at the same time.
        The Linux console takes one sequence per entry instead, and applies each as it arrives.

        0 <= index < 256 (some terminals will only have 16 or 88 colors)
        0 <= red, green, blue < 256

        The Linux console has only entries 0-15 and skips the others.
        Which terminal is in use, and so which entries it has, is up to the caller to check (:attr:`term`)
        before relying on the change.

        :param entries: list of (index, red, green, blue) tuples.
        :raises TypeError: an index or a red, green or blue value is not an integer.
        :raises ValueError: on the Linux console, an index or a red, green or blue value is outside 0-255,
            which its sequence cannot carry.
        """
        checked: list[tuple[int, int, int, int]] = []
        for entry in entries:
            try:
                index, red, green, blue = map(operator.index, entry)
            except TypeError as exc:
                raise TypeError(f"Palette entry has a value that is not an integer: {entry!r}") from exc
            checked.append((index, red, green, blue))
        entries = checked

        if _is_linux_console(self.term):
            sequences: list[str] = []
            applied: list[tuple[int, int, int, int]] = []
            for index, red, green, blue in entries:
                if index not in range(256) or any(value not in range(256) for value in (red, green, blue)):
                    raise ValueError(f"Linux console palette entry out of range: {(index, red, green, blue)!r}")
                if index < 16:
                    sequences.append(f"{escape.LINUX_SET_PALETTE}{index:x}{red:02x}{green:02x}{blue:02x}")
                    applied.append((index, red, green, blue))
            entries = applied
            self.write("".join(sequences))
        elif self.term == "fbterm":
            modify = [f"{index:d};{red:d};{green:d};{blue:d}" for index, red, green, blue in entries]
            self.write(f"{escape.CSI}3;{';'.join(modify)}}}")
        else:
            modify = [f"{index:d};rgb:{red:02x}/{green:02x}/{blue:02x}" for index, red, green, blue in entries]
            self.write(f"{escape.OSC}4;{';'.join(modify)}{escape.ST}")
        self.flush()
        self._modified_palette_entries.update(index for index, _red, _green, _blue in entries)

    # shortcut for creating an AttrSpec with this screen object's
    # number of colors
    def AttrSpec(self, fg: str, bg: str, *, hyperlink: Hyperlink | str | None = None) -> AttrSpec:
        """Create an :class:`AttrSpec` using this screen's number of colors.

        :param fg: the foreground color and settings, as for :class:`AttrSpec`
        :param bg: the background color, as for :class:`AttrSpec`
        :param hyperlink: the terminal hyperlink of the text, as for :class:`AttrSpec`
        :raises AttrSpecError: *fg* or *bg* is invalid or needs more colors than this screen has.
        :raises ValueError: *hyperlink* is a string that is not a valid :class:`Hyperlink` URI.
        """
        return AttrSpec(fg, bg, self.colors, hyperlink=hyperlink)
