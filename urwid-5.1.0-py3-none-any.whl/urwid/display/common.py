# Urwid common display code
#    Copyright (C) 2004-2011  Ian Ward
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/


"""Colour and attribute handling and the base classes shared by all display modules."""

from __future__ import annotations

import abc
import dataclasses
import enum
import functools
import logging
import os
import sys
import types
import typing

from urwid import signals
from urwid.util import LayeredAttr, StoppingContext, int_scale

if typing.TYPE_CHECKING:
    from collections.abc import Hashable, Iterable, Mapping, Sequence
    from typing import Literal, Self

    from urwid import Canvas

    # One register_palette() item:
    # (name, like_other_name)
    # or the 3, 4 or 6 positional arguments of register_palette_entry().
    # A name is any hashable value, None being the default attribute.
    PaletteEntry = (
        tuple[Hashable, Hashable]
        | tuple[Hashable, str, str]
        | tuple[Hashable, str, str, str | tuple[str, ...] | None]
        | tuple[
            Hashable,
            str,
            str,
            str | tuple[str, ...] | None,
            str | None,
            str | None,
        ]
    )

IS_WINDOWS = sys.platform == "win32"

# for replacing unprintable bytes with '?'
UNPRINTABLE_TRANS_TABLE = bytes.maketrans(bytes(range(32)), b"?" * 32)
# for replacing decoded C1 control characters (U+0080-U+009F) with '?'
UNPRINTABLE_C1_TRANS_TABLE = str.maketrans(dict.fromkeys(range(0x80, 0xA0), "?"))


# signals sent by BaseScreen
UPDATE_PALETTE_ENTRY = "update palette entry"
INPUT_DESCRIPTORS_CHANGED = "input descriptors changed"


# AttrSpec internal values
_BASIC_START = 0  # first index of basic color aliases
_CUBE_START = 16  # first index of color cube
_CUBE_SIZE_256 = 6  # one side of the color cube
_GRAY_SIZE_256 = 24
_GRAY_START_256 = _CUBE_SIZE_256**3 + _CUBE_START
_CUBE_WHITE_256 = _GRAY_START_256 - 1
_CUBE_SIZE_88 = 4
_GRAY_SIZE_88 = 8
_GRAY_START_88 = _CUBE_SIZE_88**3 + _CUBE_START
_CUBE_WHITE_88 = _GRAY_START_88 - 1
_CUBE_BLACK = _CUBE_START

# values copied from xterm 256colres.h:
_CUBE_STEPS_256 = [0x00, 0x5F, 0x87, 0xAF, 0xD7, 0xFF]
_GRAY_STEPS_256 = [
    0x08,
    0x12,
    0x1C,
    0x26,
    0x30,
    0x3A,
    0x44,
    0x4E,
    0x58,
    0x62,
    0x6C,
    0x76,
    0x80,
    0x84,
    0x94,
    0x9E,
    0xA8,
    0xB2,
    0xBC,
    0xC6,
    0xD0,
    0xDA,
    0xE4,
    0xEE,
]
# values copied from xterm 88colres.h:
_CUBE_STEPS_88 = [0x00, 0x8B, 0xCD, 0xFF]
_GRAY_STEPS_88 = [0x2E, 0x5C, 0x73, 0x8B, 0xA2, 0xB9, 0xD0, 0xE7]
# values copied from X11/rgb.txt and XTerm-col.ad:
_BASIC_COLOR_VALUES = (
    (0, 0, 0),
    (205, 0, 0),
    (0, 205, 0),
    (205, 205, 0),
    (0, 0, 238),
    (205, 0, 205),
    (0, 205, 205),
    (229, 229, 229),
    (127, 127, 127),
    (255, 0, 0),
    (0, 255, 0),
    (255, 255, 0),
    (0x5C, 0x5C, 0xFF),
    (255, 0, 255),
    (0, 255, 255),
    (255, 255, 255),
)

_COLOR_VALUES_256: tuple[tuple[int, int, int], ...] = (
    *_BASIC_COLOR_VALUES,
    *[(r, g, b) for r in _CUBE_STEPS_256 for g in _CUBE_STEPS_256 for b in _CUBE_STEPS_256],
    *[(gr, gr, gr) for gr in _GRAY_STEPS_256],
)
_COLOR_VALUES_88: tuple[tuple[int, int, int], ...] = (
    *_BASIC_COLOR_VALUES,
    *[(r, g, b) for r in _CUBE_STEPS_88 for g in _CUBE_STEPS_88 for b in _CUBE_STEPS_88],
    *[(gr, gr, gr) for gr in _GRAY_STEPS_88],
)

if len(_COLOR_VALUES_256) != 256:
    raise RuntimeError(_COLOR_VALUES_256)
if len(_COLOR_VALUES_88) != 88:
    raise RuntimeError(_COLOR_VALUES_88)

# fmt: off
_FG_COLOR_MASK =      0x000000ffffff
_BG_COLOR_MASK =      0xffffff000000
_FG_BASIC_COLOR =    0x1000000000000
_FG_HIGH_COLOR =     0x2000000000000
_FG_TRUE_COLOR =     0x4000000000000
_BG_BASIC_COLOR =    0x8000000000000
_BG_HIGH_COLOR =    0x10000000000000
_BG_TRUE_COLOR =    0x20000000000000
_BG_SHIFT = 24
_HIGH_88_COLOR =    0x40000000000000
_HIGH_TRUE_COLOR =  0x80000000000000
_STANDOUT =        0x100000000000000
_UNDERLINE =       0x200000000000000
_BOLD =            0x400000000000000
_BLINK =           0x800000000000000
_ITALICS =        0x1000000000000000
_STRIKETHROUGH =  0x2000000000000000
_FAINT =          0x4000000000000000
_FG_INHERIT =     0x8000000000000000
_BG_INHERIT =    0x10000000000000000
# fmt: on

# a setting turned off explicitly ('no-bold'), kept apart from "not mentioned" in every attribute, as a terminal
# keeps an SGR reset;
# the shift puts the off bits (65-71) above _BG_INHERIT (64)
_SETTING_OFF_SHIFT = 9
_SETTINGS_OFF_MASK = (
    _STANDOUT | _UNDERLINE | _BOLD | _BLINK | _ITALICS | _STRIKETHROUGH | _FAINT
) << _SETTING_OFF_SHIFT

_FG_MASK = (
    _FG_COLOR_MASK
    | _FG_BASIC_COLOR
    | _FG_HIGH_COLOR
    | _STANDOUT
    | _UNDERLINE
    | _BLINK
    | _BOLD
    | _ITALICS
    | _STRIKETHROUGH
    | _FAINT
    | _FG_INHERIT
    | _SETTINGS_OFF_MASK
)
_BG_MASK = _BG_COLOR_MASK | _BG_BASIC_COLOR | _BG_HIGH_COLOR | _BG_INHERIT
_INHERIT_MASK = _FG_INHERIT | _BG_INHERIT

DEFAULT = "default"
#: colour keyword taking the colour from the enclosing attribute (:meth:`AttrSpec.layered_over`)
INHERIT = "inherit"
BLACK = "black"
DARK_RED = "dark red"
DARK_GREEN = "dark green"
BROWN = "brown"
DARK_BLUE = "dark blue"
DARK_MAGENTA = "dark magenta"
DARK_CYAN = "dark cyan"
LIGHT_GRAY = "light gray"
DARK_GRAY = "dark gray"
LIGHT_RED = "light red"
LIGHT_GREEN = "light green"
YELLOW = "yellow"
LIGHT_BLUE = "light blue"
LIGHT_MAGENTA = "light magenta"
LIGHT_CYAN = "light cyan"
WHITE = "white"

_BASIC_COLORS = [
    BLACK,
    DARK_RED,
    DARK_GREEN,
    BROWN,
    DARK_BLUE,
    DARK_MAGENTA,
    DARK_CYAN,
    LIGHT_GRAY,
    DARK_GRAY,
    LIGHT_RED,
    LIGHT_GREEN,
    YELLOW,
    LIGHT_BLUE,
    LIGHT_MAGENTA,
    LIGHT_CYAN,
    WHITE,
]
# name -> index, for the O(1) lookup AttrSpec needs on every color it parses
# (_BASIC_COLORS itself is kept for the reverse, index -> name, direction)
_BASIC_COLOR_INDEX = {color: index for index, color in enumerate(_BASIC_COLORS)}

_ATTRIBUTES = {
    "bold": _BOLD,
    "italics": _ITALICS,
    "underline": _UNDERLINE,
    "blink": _BLINK,
    "standout": _STANDOUT,
    "strikethrough": _STRIKETHROUGH,
    "faint": _FAINT,
}
_SETTING_OFF_PREFIX = "no-"
_ATTRIBUTES_OFF = {f"{_SETTING_OFF_PREFIX}{name}": flag << _SETTING_OFF_SHIFT for name, flag in _ATTRIBUTES.items()}

# AttrSpec.__init__() and __set_foreground()/__set_background() are called
# once per colored run of text an application constructs, so these are
# hoisted to module scope rather than re-built as set literals on every call.
_VALID_COLOR_COUNTS = frozenset({1, 16, 88, 256, 2**24})
_DEFAULT_COLOR_NAMES = frozenset({"", "default"})
# BaseScreen.resolve_attr() memo size: attrs built from AttrSpec instances (ANSI text, terminals) are unbounded
_RESOLVED_ATTRS_LIMIT = 4096
# urwid's own caps on Hyperlink fields: VTE and iTerm2 refuse longer URIs, and VTE refuses longer ids
_HYPERLINK_URI_MAX_LEN = 2083
_HYPERLINK_ID_MAX_LEN = 250
# URI schemes an HTML-producing screen turns into a link, none of which can run script in the page
_BROWSER_SCHEMES = frozenset({"file", "http", "https", "mailto", "sftp"})


def _value_lookup_table(values: Sequence[int], size: int) -> list[int]:
    """Generate a lookup table for finding the closest item in *values*.

    :param values: list of values in ascending order, all < size
    :param size: size of lookup table and maximum value
    :returns: one entry per value from 0 to *size* - 1, holding the index into *values* of the closest item.

    >>> _value_lookup_table([0, 7, 9], 10)
    [0, 0, 0, 0, 1, 1, 1, 1, 2, 2]
    """
    middle_values = [0] + [(values[i] + values[i + 1] + 1) // 2 for i in range(len(values) - 1)] + [size]
    lookup_table = []
    for i in range(len(middle_values) - 1):
        count = middle_values[i + 1] - middle_values[i]
        lookup_table.extend([i] * count)
    return lookup_table


_CUBE_256_LOOKUP = _value_lookup_table(_CUBE_STEPS_256, 256)
_GRAY_256_LOOKUP = _value_lookup_table([0, *_GRAY_STEPS_256, 255], 256)
_CUBE_88_LOOKUP = _value_lookup_table(_CUBE_STEPS_88, 256)
_GRAY_88_LOOKUP = _value_lookup_table([0, *_GRAY_STEPS_88, 255], 256)

# convert steps to values that will be used by string versions of the colors
# 1 hex digit for rgb and 0..100 for grayscale
_CUBE_STEPS_256_16 = [int_scale(n, 0x100, 0x10) for n in _CUBE_STEPS_256]
_GRAY_STEPS_256_101 = [int_scale(n, 0x100, 101) for n in _GRAY_STEPS_256]
_CUBE_STEPS_88_16 = [int_scale(n, 0x100, 0x10) for n in _CUBE_STEPS_88]
_GRAY_STEPS_88_101 = [int_scale(n, 0x100, 101) for n in _GRAY_STEPS_88]

# create lookup tables for 1 hex digit rgb and 0..100 for grayscale values
_CUBE_256_LOOKUP_16 = [_CUBE_256_LOOKUP[int_scale(n, 16, 0x100)] for n in range(16)]
_GRAY_256_LOOKUP_101 = [_GRAY_256_LOOKUP[int_scale(n, 101, 0x100)] for n in range(101)]
_CUBE_88_LOOKUP_16 = [_CUBE_88_LOOKUP[int_scale(n, 16, 0x100)] for n in range(16)]
_GRAY_88_LOOKUP_101 = [_GRAY_88_LOOKUP[int_scale(n, 101, 0x100)] for n in range(101)]


# The functions _gray_num_256() and _gray_num_88() do not include the gray
# values from the color cube so that the gray steps are an even width.
# The color cube grays are available by using the rgb functions.  Pure
# white and black are taken from the color cube, since the gray range does
# not include them, and the basic colors are more likely to have been
# customized by an end-user.


def _gray_num_256(gnum: int) -> int:
    """Return ths color number for gray number gnum.

    Color cube black and white are returned for 0 and 25 respectively
    since those values aren't included in the gray scale.

    """
    # grays start from index 1
    gnum -= 1

    if gnum < 0:
        return _CUBE_BLACK
    if gnum >= _GRAY_SIZE_256:
        return _CUBE_WHITE_256
    return _GRAY_START_256 + gnum


def _gray_num_88(gnum: int) -> int:
    """Return ths color number for gray number gnum.

    Color cube black and white are returned for 0 and 9 respectively
    since those values aren't included in the gray scale.

    """
    # gnums start from index 1
    gnum -= 1

    if gnum < 0:
        return _CUBE_BLACK
    if gnum >= _GRAY_SIZE_88:
        return _CUBE_WHITE_88
    return _GRAY_START_88 + gnum


def _color_desc_true(num: int) -> str:
    return f"#{num:06x}"


@functools.lru_cache(maxsize=256)
def _color_desc_256(num: int) -> str:
    """Return a string description of color number *num*.

    0..15 -> 'h0'..'h15' basic colors (as high-colors)
    16..231 -> '#000'..'#fff' color cube colors
    232..255 -> 'g3'..'g93' grays

    >>> _color_desc_256(15)
    'h15'
    >>> _color_desc_256(16)
    '#000'
    >>> _color_desc_256(17)
    '#006'
    >>> _color_desc_256(230)
    '#ffd'
    >>> _color_desc_256(233)
    'g7'
    >>> _color_desc_256(234)
    'g11'

    :raises ValueError: *num* is outside the 256-colour range.

    """
    if not 0 <= num < 256:
        raise ValueError(num)
    if num < _CUBE_START:
        return f"h{num:d}"
    if num < _GRAY_START_256:
        num -= _CUBE_START
        b, num = num % _CUBE_SIZE_256, num // _CUBE_SIZE_256
        g, num = num % _CUBE_SIZE_256, num // _CUBE_SIZE_256
        r = num % _CUBE_SIZE_256
        return f"#{_CUBE_STEPS_256_16[r]:x}{_CUBE_STEPS_256_16[g]:x}{_CUBE_STEPS_256_16[b]:x}"
    return f"g{_GRAY_STEPS_256_101[num - _GRAY_START_256]:d}"


@functools.lru_cache(maxsize=88)
def _color_desc_88(num: int) -> str:
    """Return a string description of color number *num*.

    0..15 -> 'h0'..'h15' basic colors (as high-colors)
    16..79 -> '#000'..'#fff' color cube colors
    80..87 -> 'g18'..'g90' grays

    >>> _color_desc_88(15)
    'h15'
    >>> _color_desc_88(16)
    '#000'
    >>> _color_desc_88(17)
    '#008'
    >>> _color_desc_88(78)
    '#ffc'
    >>> _color_desc_88(81)
    'g36'
    >>> _color_desc_88(82)
    'g45'

    :raises ValueError: *num* is outside the 88-colour range.

    """
    if not 0 < num < 88:
        raise ValueError(num)
    if num < _CUBE_START:
        return f"h{num:d}"
    if num < _GRAY_START_88:
        num -= _CUBE_START
        b, num = num % _CUBE_SIZE_88, num // _CUBE_SIZE_88
        g, r = num % _CUBE_SIZE_88, num // _CUBE_SIZE_88
        return f"#{_CUBE_STEPS_88_16[r]:x}{_CUBE_STEPS_88_16[g]:x}{_CUBE_STEPS_88_16[b]:x}"
    return f"g{_GRAY_STEPS_88_101[num - _GRAY_START_88]:d}"


@functools.lru_cache(maxsize=512)
def _parse_color_true(desc: str) -> int | None:
    if (c := _parse_color_256(desc)) is not None:
        (r, g, b) = _COLOR_VALUES_256[c]
        return (r << 16) + (g << 8) + b

    if not desc.startswith("#"):
        return None

    if len(desc) == 7:
        h = desc[1:]
        return int(h, 16)

    if len(desc) == 4:
        h = f"0x{desc[1]}0{desc[2]}0{desc[3]}"
        return int(h, 16)

    return None


@functools.lru_cache(maxsize=512)
def _parse_color_256(desc: str) -> int | None:
    """Return a color number for the description *desc*.

    'h0'..'h255' -> 0..255 actual color number
    '#000'..'#fff' -> 16..231 color cube colors
    'g0'..'g100' -> 16, 232..255, 231 grays and color cube black/white
    'g#00'..'g#ff' -> 16, 232...255, 231 gray and color cube black/white

    :returns: None if desc is invalid.

    >>> _parse_color_256("h142")
    142
    >>> _parse_color_256("#f00")
    196
    >>> _parse_color_256("g100")
    231
    >>> _parse_color_256("g#80")
    244
    """
    if len(desc) > 4:
        # keep the length within reason before parsing
        return None
    try:
        if desc.startswith("h"):
            # high-color number
            num = int(desc[1:], 10)
            if num < 0 or num > 255:
                return None
            return num

        if desc.startswith("#") and len(desc) == 4:
            # color-cube coordinates
            if (rgb := int(desc[1:], 16)) >= 0:
                b, rgb = rgb % 16, rgb // 16
                g, r = rgb % 16, rgb // 16
                # find the closest rgb values
                r = _CUBE_256_LOOKUP_16[r]
                g = _CUBE_256_LOOKUP_16[g]
                b = _CUBE_256_LOOKUP_16[b]
                return _CUBE_START + (r * _CUBE_SIZE_256 + g) * _CUBE_SIZE_256 + b

            return None

        # Only remaining possibility is gray value
        if desc.startswith("g#"):
            # hex value 00..ff
            gray = int(desc[2:], 16)  # noqa: FURB166
            if gray < 0 or gray > 255:
                return None
            gray = _GRAY_256_LOOKUP[gray]
        elif desc.startswith("g"):
            # decimal value 0..100
            gray = int(desc[1:], 10)
            if gray < 0 or gray > 100:
                return None
            gray = _GRAY_256_LOOKUP_101[gray]
        else:
            return None
        if gray == 0:
            return _CUBE_BLACK
        gray -= 1
        if gray == _GRAY_SIZE_256:
            return _CUBE_WHITE_256
        return _GRAY_START_256 + gray

    except ValueError:
        return None


@functools.lru_cache(maxsize=512)
def _true_to_256(desc: str) -> str | None:
    if not (desc.startswith("#") and len(desc) == 7):
        return None

    c256 = _parse_color_256("#" + "".join(format(int(x, 16) // 16, "x") for x in (desc[1:3], desc[3:5], desc[5:7])))
    return _color_desc_256(typing.cast("int", c256))  # we control input


@functools.lru_cache(maxsize=512)
def _parse_color_88(desc: str) -> int | None:
    """Return a color number for the description *desc*.

    'h0'..'h87' -> 0..87 actual color number
    '#000'..'#fff' -> 16..79 color cube colors
    'g0'..'g100' -> 16, 80..87, 79 grays and color cube black/white
    'g#00'..'g#ff' -> 16, 80...87, 79 gray and color cube black/white

    :returns: None if desc is invalid.

    >>> _parse_color_88("h142")
    >>> _parse_color_88("h42")
    42
    >>> _parse_color_88("#f00")
    64
    >>> _parse_color_88("g100")
    79
    >>> _parse_color_88("g#80")
    83
    """
    if len(desc) == 7:
        desc = desc[0:2] + desc[3] + desc[5]
    if len(desc) > 4:
        # keep the length within reason before parsing
        return None
    try:
        if desc.startswith("h"):
            # high-color number
            num = int(desc[1:], 10)
            if num < 0 or num > 87:
                return None
            return num

        if desc.startswith("#") and len(desc) == 4:
            # color-cube coordinates
            if (rgb := int(desc[1:], 16)) >= 0:
                b, rgb = rgb % 16, rgb // 16
                g, r = rgb % 16, rgb // 16
                # find the closest rgb values
                r = _CUBE_88_LOOKUP_16[r]
                g = _CUBE_88_LOOKUP_16[g]
                b = _CUBE_88_LOOKUP_16[b]
                return _CUBE_START + (r * _CUBE_SIZE_88 + g) * _CUBE_SIZE_88 + b

            return None

        # Only remaining possibility is gray value
        if desc.startswith("g#"):
            # hex value 00..ff
            gray = int(desc[2:], 16)  # noqa: FURB166
            if gray < 0 or gray > 255:
                return None
            gray = _GRAY_88_LOOKUP[gray]
        elif desc.startswith("g"):
            # decimal value 0..100
            gray = int(desc[1:], 10)
            if gray < 0 or gray > 100:
                return None
            gray = _GRAY_88_LOOKUP_101[gray]
        else:
            return None
        if gray == 0:
            return _CUBE_BLACK
        gray -= 1
        if gray == _GRAY_SIZE_88:
            return _CUBE_WHITE_88
        return _GRAY_START_88 + gray

    except ValueError:
        return None


class AttrSpecError(Exception):
    """Raised when an :class:`AttrSpec` is constructed with an invalid color specification."""


@dataclasses.dataclass(frozen=True, slots=True, weakref_slot=True)
class Hyperlink:
    """Terminal hyperlink (OSC 8) carried by an :class:`AttrSpec`.

    The fields keep the names of the OSC 8 specification.
    Only printable ASCII is accepted, so a link cannot inject other escape sequences.
    The URI is limited to 2083 characters and the id to 250: these are urwid's compatibility limits,
    taken from the terminals that refuse longer values (VTE and iTerm2 for the URI, VTE for the id).
    The specification itself sets no limit.

    An empty URI is the explicit "no link" state, :data:`NO_HYPERLINK`:
    it hides the link of an enclosing attribute.

    :param uri: the link target
    :param id: groups the cells of one link that the terminal highlights together,
        when the link is drawn in several separate runs
    :raises ValueError: *uri* or *id* holds a character outside printable ASCII or is too long,
        *id* holds ``:`` or ``;``, or *id* is given with an empty *uri*.

    >>> Hyperlink("https://urwid.org", id="home")
    Hyperlink(uri='https://urwid.org', id='home')
    """

    uri: str
    _: dataclasses.KW_ONLY
    id: str = ""

    def __post_init__(self) -> None:
        """Validate the fields as the class docstring describes."""
        for name, value, limit in (
            ("uri", self.uri, _HYPERLINK_URI_MAX_LEN),
            ("id", self.id, _HYPERLINK_ID_MAX_LEN),
        ):
            if not (value.isascii() and value.isprintable()):
                raise ValueError(f"Hyperlink {name} must be printable ASCII: {value!r}")
            if len(value) > limit:
                raise ValueError(
                    f"Hyperlink {name} is {len(value):d} characters long, "
                    f"over urwid's compatibility limit of {limit:d}, as some terminals refuse longer values"
                )
        if ":" in self.id or ";" in self.id:
            raise ValueError(f"Hyperlink id must not contain ':' or ';': {self.id!r}")
        if not self.uri and self.id:
            raise ValueError(f"Hyperlink id {self.id!r} given without a URI")


#: hyperlink of an attribute that hides the link of the enclosing attribute
NO_HYPERLINK = Hyperlink("")


def _browser_href(link: Hyperlink) -> str | None:
    """Return the URI of *link* to use as an HTML ``href``, or ``None`` when a browser must not follow it.

    The URI is stripped of spaces the way the WHATWG URL parser strips it before reading the scheme
    (the control characters it also strips cannot occur in a :class:`Hyperlink`).
    Only the schemes in ``_BROWSER_SCHEMES`` are allowed, so a link can never run script in the page.

    >>> _browser_href(Hyperlink(" https://urwid.org"))
    'https://urwid.org'
    >>> _browser_href(Hyperlink("JaVaScRiPt:alert(1)")) is None
    True
    """
    href = link.uri.strip(" ")
    scheme, sep, _rest = href.partition(":")
    if sep and scheme.lower() in _BROWSER_SCHEMES:
        return href
    return None


class _Keep(enum.Enum):
    """Default of :meth:`AttrSpec.copy_modified` arguments for which ``None`` is a real value."""

    KEEP = enum.auto()


class AttrSpec:
    """Text attribute specification, encoding foreground and background colors and display settings."""

    __slots__ = ("__hash_value", "__hyperlink", "__value")

    def __init__(
        self,
        fg: str = INHERIT,
        bg: str = INHERIT,
        colors: Literal[1, 16, 88, 256, 16777216] = 256,
        *,
        hyperlink: Hyperlink | str | None = None,
    ) -> None:
        """
        :param fg: a string containing a comma-separated foreground color and settings

              Color values:
              'default' (use the terminal's default foreground),
              'inherit' (take the color from the enclosing attribute, see :meth:`layered_over`),
              'black', 'dark red', 'dark green', 'brown', 'dark blue',
              'dark magenta', 'dark cyan', 'light gray', 'dark gray',
              'light red', 'light green', 'yellow', 'light blue',
              'light magenta', 'light cyan', 'white'

              High-color example values:
              '#009' (0% red, 0% green, 60% red, like HTML colors)
              '#23facc' (RRGGBB hex color code)
              '#fcc' (100% red, 80% green, 80% blue)
              'g40' (40% gray, decimal), 'g#cc' (80% gray, hex),
              '#000', 'g0', 'g#00' (black),
              '#fff', 'g100', 'g#ff' (white)
              'h8' (color number 8), 'h255' (color number 255)

              Setting:
              'bold', 'italics', 'underline', 'blink', 'standout', 'strikethrough', 'faint';
              with 'no-' in front ('no-bold') a setting is turned off rather than taken from the
              enclosing attribute; it is part of the attribute, so 'red,no-bold' and 'red' are unequal

              Some terminals use 'bold' for bright colors.
              Most terminals ignore the 'blink' setting.
              If the color is not given then 'default' will be assumed.

        :param bg: a string containing the background color

              Color values:
              'default' (use the terminal's default background),
              'inherit' (take the color from the enclosing attribute),
              'black', 'dark red', 'dark green', 'brown', 'dark blue',
              'dark magenta', 'dark cyan', 'light gray'

              High-color exaples:
              see fg examples above

              An empty string will be treated the same as 'default'.

        :param colors: the maximum colors available for the specification

                   Valid values include: 1, 16, 88, 256, and 2**24.  High-color
                   values are only usable with 88, 256, or 2**24 colors.  With
                   1 color only the foreground settings may be used.

        :param hyperlink: the terminal hyperlink of the text, a string being its URI;
            ``None`` takes the link of the enclosing attribute, and :data:`NO_HYPERLINK` hides it.
        :raises AttrSpecError: *colors* is not a supported palette size.
            *fg* or *bg* is invalid, or needs more colours than *colors*.
        :raises ValueError: *hyperlink* is a string that is not a valid :class:`Hyperlink` URI.

        >>> AttrSpec("dark red", "light gray", 16)
        AttrSpec('dark red', 'light gray')
        >>> AttrSpec("yellow, underline, bold", "dark blue")
        AttrSpec('yellow,bold,underline', 'dark blue')
        >>> AttrSpec("#ddb", "#004", 256)  # closest colors will be found
        AttrSpec('#dda', '#006')
        >>> AttrSpec("#ddb", "#004", 88)
        AttrSpec('#ccc', '#000', colors=88)
        >>> AttrSpec("inherit,bold", "dark blue")
        AttrSpec('inherit,bold', 'dark blue')
        >>> AttrSpec(hyperlink="https://urwid.org")
        AttrSpec('inherit', 'inherit', hyperlink=Hyperlink(uri='https://urwid.org', id=''))
        """
        if colors not in _VALID_COLOR_COUNTS:
            raise AttrSpecError(f"invalid number of colors ({colors:d}).")
        self.__value = 0 | _HIGH_88_COLOR * (colors == 88) | _HIGH_TRUE_COLOR * (colors == 2**24)
        self.__set_foreground(fg)
        self.__set_background(bg)
        if self.colors > colors:
            raise AttrSpecError(
                f"foreground/background ({fg!r}/{bg!r}) require more colors than have been specified ({colors:d})."
            )
        self.__hyperlink = Hyperlink(hyperlink) if isinstance(hyperlink, str) else hyperlink
        self.__hash_value = hash((self.__class__, self.__value, self.__hyperlink))

    def copy_modified(
        self,
        fg: str | None = None,
        bg: str | None = None,
        colors: Literal[1, 16, 88, 256, 16777216] | None = None,
        *,
        hyperlink: Hyperlink | str | Literal[_Keep.KEEP] | None = _Keep.KEEP,
    ) -> Self:
        """Return a new :class:`AttrSpec`, replacing *fg*, *bg*, *colors* and/or *hyperlink* with the given values.

        Without *colors*, the result uses 88 colors or true color when this specification was made for them,
        else 256 colors, so a color can be added to a specification that has none.
        The hyperlink is kept unless *hyperlink* is given; ``None`` makes the result take the enclosing one.

        The result is built with this object's class.
        The *hyperlink* keyword is passed to its constructor only when the result has a link,
        so a subclass whose constructor takes only *fg*, *bg* and *colors* works for every other change.

        :raises AttrSpecError: *colors* is not a supported palette size, or *fg* or *bg* is invalid or needs
            more colors than the result has.
        :raises ValueError: *hyperlink* is a string that is not a valid :class:`Hyperlink` URI.
        :raises TypeError: the result has a link and the constructor of this object's class does not accept it.

        >>> AttrSpec("inherit,bold", "inherit").copy_modified(bg="dark blue")
        AttrSpec('inherit,bold', 'dark blue')
        >>> AttrSpec(hyperlink="https://urwid.org").copy_modified(hyperlink=None)
        AttrSpec('inherit', 'inherit')
        """
        if fg is None:
            foreground = self.foreground
        else:
            foreground = fg

        if bg is None:
            background = self.background
        else:
            background = bg

        new_colors = self.__color_mode() if colors is None else colors
        if (link := self.__hyperlink if hyperlink is _Keep.KEEP else hyperlink) is None:
            return self.__class__(foreground, background, new_colors)
        return self.__class__(foreground, background, new_colors, hyperlink=link)

    def __color_mode(self) -> Literal[88, 256, 16777216]:
        """Return the color mode this specification was made for: 88 colors, true color, or else 256 colors."""
        if self.__value & _HIGH_88_COLOR:
            return 88
        if self.__value & _HIGH_TRUE_COLOR:
            return 16777216
        return 256

    def __hash__(self) -> int:
        """Instance is immutable and hashable."""
        return self.__hash_value

    @property
    def _value(self) -> int:
        """Read-only value access."""
        return self.__value

    @property
    def hyperlink(self) -> Hyperlink | None:
        """Return the terminal hyperlink, ``None`` when it is taken from the enclosing attribute."""
        return self.__hyperlink

    def style_only(self) -> AttrSpec:
        """Return this attribute without its hyperlink, for code that only draws colors and settings.

        >>> AttrSpec("yellow", "dark blue", hyperlink="https://urwid.org").style_only()
        AttrSpec('yellow', 'dark blue')
        """
        if self.__hyperlink is None:
            return self
        return self.copy_modified(hyperlink=None)

    @property
    def foreground_basic(self) -> bool:
        """Return whether the foreground color is one of the 16 basic colors."""
        return self.__value & _FG_BASIC_COLOR != 0

    @property
    def foreground_high(self) -> bool:
        """Return whether the foreground color is a 88- or 256-color palette entry."""
        return self.__value & _FG_HIGH_COLOR != 0

    @property
    def foreground_true(self) -> bool:
        """Return whether the foreground color is a 24-bit true color."""
        return self.__value & _FG_TRUE_COLOR != 0

    @property
    def foreground_number(self) -> int:
        """Return the encoded foreground color number."""
        return self.__value & _FG_COLOR_MASK

    @property
    def foreground_inherit(self) -> bool:
        """Return whether the foreground color is taken from the enclosing attribute."""
        return self.__value & _FG_INHERIT != 0

    @property
    def background_basic(self) -> bool:
        """Return whether the background color is one of the 16 basic colors."""
        return self.__value & _BG_BASIC_COLOR != 0

    @property
    def background_high(self) -> bool:
        """Return whether the background color is a 88- or 256-color palette entry."""
        return self.__value & _BG_HIGH_COLOR != 0

    @property
    def background_true(self) -> bool:
        """Return whether the background color is a 24-bit true color."""
        return self.__value & _BG_TRUE_COLOR != 0

    @property
    def background_number(self) -> int:
        """Return the encoded background color number."""
        return (self.__value & _BG_COLOR_MASK) >> _BG_SHIFT

    @property
    def background_inherit(self) -> bool:
        """Return whether the background color is taken from the enclosing attribute."""
        return self.__value & _BG_INHERIT != 0

    @property
    def italics(self) -> bool:
        """Return whether the italics setting is enabled."""
        return self.__value & _ITALICS != 0

    @property
    def bold(self) -> bool:
        """Return whether the bold setting is enabled."""
        return self.__value & _BOLD != 0

    @property
    def underline(self) -> bool:
        """Return whether the underline setting is enabled."""
        return self.__value & _UNDERLINE != 0

    @property
    def blink(self) -> bool:
        """Return whether the blink setting is enabled."""
        return self.__value & _BLINK != 0

    @property
    def standout(self) -> bool:
        """Return whether the standout setting is enabled."""
        return self.__value & _STANDOUT != 0

    @property
    def strikethrough(self) -> bool:
        """Return whether the strikethrough setting is enabled."""
        return self.__value & _STRIKETHROUGH != 0

    @property
    def faint(self) -> bool:
        """Return whether the faint setting is enabled."""
        return self.__value & _FAINT != 0

    @property
    def colors(self) -> Literal[1, 16, 88, 256, 16777216]:
        """
        Return the maximum colors required for this object.

        Returns 16777216, 256, 88, 16 or 1.
        """
        if self.__value & _HIGH_88_COLOR:
            return 88
        if self.__value & (_BG_HIGH_COLOR | _FG_HIGH_COLOR):
            return 256
        if self.__value & (_BG_TRUE_COLOR | _FG_TRUE_COLOR):
            return 16777216  # we have to return explicit 2**24 instead of inline calculation
        if self.__value & (_BG_BASIC_COLOR | _FG_BASIC_COLOR):
            return 16
        return 1

    def __repr__(self) -> str:
        """Return an executable python representation of the AttrSpec object."""
        args = f"{self.foreground!r}, {self.background!r}"
        if self.colors == 88:
            # 88-color mode is the only one that is handled differently
            args = f"{args}, colors=88"
        if self.__hyperlink is not None:
            args = f"{args}, hyperlink={self.__hyperlink!r}"
        return f"{self.__class__.__name__}({args})"

    def _foreground_color(self) -> str:
        """Return only the color component of the foreground."""
        if self.foreground_inherit:
            return INHERIT
        if not (self.foreground_basic or self.foreground_high or self.foreground_true):
            return "default"
        if self.foreground_basic:
            return _BASIC_COLORS[self.foreground_number]
        if self.colors == 88:
            return _color_desc_88(self.foreground_number)
        if self.colors == 2**24:
            return _color_desc_true(self.foreground_number)
        return _color_desc_256(self.foreground_number)

    @property
    def foreground(self) -> str:
        """Return the foreground color and settings as a comma-separated string."""
        return (
            self._foreground_color()
            + ",bold" * self.bold
            + ",italics" * self.italics
            + ",standout" * self.standout
            + ",blink" * self.blink
            + ",underline" * self.underline
            + ",strikethrough" * self.strikethrough
            + ",faint" * self.faint
            + "".join(f",{name}" for name, flag in _ATTRIBUTES_OFF.items() if self.__value & flag)
        )

    def __set_foreground(self, foreground: str) -> None:
        """
        Parse and store the foreground colour and settings.

        :raises AttrSpecError: *foreground* names an unrecognised colour, repeats a setting, or gives more than one
            colour.
        """
        color = None
        scolor: int | None
        flags = 0
        # handle comma-separated foreground
        for part in foreground.split(","):
            part = part.strip()  # noqa: PLW2901
            if (on_flag := _ATTRIBUTES.get(part.removeprefix(_SETTING_OFF_PREFIX))) is not None:
                # parse and store "settings"/attributes in flags, a setting and its "no-" form being one setting
                off_flag = on_flag << _SETTING_OFF_SHIFT
                attribute_flag = off_flag if part.startswith(_SETTING_OFF_PREFIX) else on_flag
                if flags & (on_flag | off_flag):
                    raise AttrSpecError(
                        f"Setting {part!r} repeats or contradicts another in foreground ({foreground!r})"
                    )
                flags |= attribute_flag
                continue
            # past this point we must be specifying a color
            if part in _DEFAULT_COLOR_NAMES:
                scolor = 0
            elif part == INHERIT:
                scolor = 0
                flags |= _FG_INHERIT
            elif (basic_color := _BASIC_COLOR_INDEX.get(part)) is not None:
                scolor = basic_color
                flags |= _FG_BASIC_COLOR
            elif self.__value & _HIGH_88_COLOR:
                scolor = _parse_color_88(part)
                flags |= _FG_HIGH_COLOR
            elif self.__value & _HIGH_TRUE_COLOR:
                scolor = _parse_color_true(part)
                flags |= _FG_TRUE_COLOR
            else:
                scolor = _parse_color_256(_true_to_256(part) or part)
                flags |= _FG_HIGH_COLOR
            # _parse_color_*() return None for unrecognized colors
            if scolor is None:
                raise AttrSpecError(f"Unrecognised color specification {part!r} in foreground ({foreground!r})")
            if color is not None:
                raise AttrSpecError(f"More than one color given for foreground ({foreground!r})")
            color = scolor
        if color is None:
            color = 0
        self.__value = (self.__value & ~_FG_MASK) | color | flags

    @property
    def background(self) -> str:
        """Return the background color."""
        if self.background_inherit:
            return INHERIT
        if not (self.background_basic or self.background_high or self.background_true):
            return "default"
        if self.background_basic:
            return _BASIC_COLORS[self.background_number]
        if self.__value & _HIGH_88_COLOR:
            return _color_desc_88(self.background_number)
        if self.colors == 2**24:
            return _color_desc_true(self.background_number)
        return _color_desc_256(self.background_number)

    def __set_background(self, background: str) -> None:
        """
        Parse and store the background colour.

        :raises AttrSpecError: *background* names an unrecognised colour.
        """
        flags = 0
        color: int | None
        if background in _DEFAULT_COLOR_NAMES:
            color = 0
        elif background == INHERIT:
            color = 0
            flags |= _BG_INHERIT
        elif (basic_color := _BASIC_COLOR_INDEX.get(background)) is not None:
            color = basic_color
            flags |= _BG_BASIC_COLOR
        elif self.__value & _HIGH_88_COLOR:
            color = _parse_color_88(background)
            flags |= _BG_HIGH_COLOR
        elif self.__value & _HIGH_TRUE_COLOR:
            color = _parse_color_true(background)
            flags |= _BG_TRUE_COLOR
        else:
            color = _parse_color_256(_true_to_256(background) or background)
            flags |= _BG_HIGH_COLOR
        if color is None:
            raise AttrSpecError(f"Unrecognised color specification in background ({background!r})")
        self.__value = (self.__value & ~_BG_MASK) | (color << _BG_SHIFT) | flags

    def get_rgb_values(self) -> tuple[int | None, int | None, int | None, int | None, int | None, int | None]:
        """Return ``(fg_red, fg_green, fg_blue, bg_red, bg_green, bg_blue)`` color components.

        Each component is in the range 0-255.
        Values are taken from the XTerm defaults and may not exactly match the user's terminal.

        If the foreground or background is 'default' or 'inherit' then all their components will be returned as None.

        >>> AttrSpec("yellow", "#ccf", colors=88).get_rgb_values()
        (255, 255, 0, 205, 205, 255)
        >>> AttrSpec("default", "g92").get_rgb_values()
        (None, None, None, 238, 238, 238)

        :raises ValueError: this AttrSpec holds a colour number outside the 88-colour range.
        """
        vals: tuple[int | None, int | None, int | None]
        if not (self.foreground_basic or self.foreground_high or self.foreground_true):
            vals = (None, None, None)
        elif self.colors == 88:
            if self.foreground_number >= 88:
                raise ValueError(f"Invalid AttrSpec _value: {self.foreground_number!r}")
            vals = _COLOR_VALUES_88[self.foreground_number]
        elif self.foreground_true:
            h = f"{self.foreground_number:06x}"
            vals = typing.cast(
                "tuple[int, int, int]",
                tuple(int(x, 16) for x in (h[0:2], h[2:4], h[4:6])),
            )
        else:
            vals = _COLOR_VALUES_256[self.foreground_number]

        bg_vals: tuple[int | None, int | None, int | None]
        if not (self.background_basic or self.background_high or self.background_true):
            bg_vals = (None, None, None)
        elif self.colors == 88:
            if self.background_number >= 88:
                raise ValueError(f"Invalid AttrSpec _value: {self.background_number!r}")
            bg_vals = _COLOR_VALUES_88[self.background_number]
        elif self.background_true:
            h = f"{self.background_number:06x}"
            bg_vals = typing.cast(
                "tuple[int, int, int]",
                tuple(int(x, 16) for x in (h[0:2], h[2:4], h[4:6])),
            )
        else:
            bg_vals = _COLOR_VALUES_256[self.background_number]

        fg_red, fg_green, fg_blue = vals
        bg_red, bg_green, bg_blue = bg_vals
        return (fg_red, fg_green, fg_blue, bg_red, bg_green, bg_blue)

    def layered_over(
        self,
        outer: AttrSpec,
        *,
        colors: Literal[1, 16, 88, 256, 16777216] | None = None,
    ) -> AttrSpec:
        """Return this attribute with its 'inherit' colors and its missing hyperlink taken from *outer*.

        An attribute with no 'inherit' color is opaque: its colors and settings are kept unchanged.
        Otherwise, each setting this attribute turns on ('bold') or off ('no-bold') is kept,
        and a setting it does not mention is taken from *outer*.
        The result may still inherit a color, when *outer* inherits it too.
        The hyperlink is resolved on its own: without one, this attribute takes the hyperlink of *outer*.
        The result is a plain :class:`AttrSpec` whenever it differs from this attribute.

        :param outer: the enclosing attribute
        :param colors: the color mode of the result, normally the terminal's;
            ``None`` uses the larger color mode of the two attributes
        :raises AttrSpecError: a color of either attribute needs more colors than *colors*.

        >>> AttrSpec("dark red,bold", "inherit").layered_over(AttrSpec("inherit,underline", "dark blue"))
        AttrSpec('dark red,bold,underline', 'dark blue')
        >>> AttrSpec("dark red", "default").layered_over(AttrSpec("yellow", "dark blue"))
        AttrSpec('dark red', 'default')
        >>> AttrSpec("inherit,no-bold", "inherit").layered_over(AttrSpec("yellow,bold,underline", "dark blue"))
        AttrSpec('yellow,underline,no-bold', 'dark blue')
        >>> AttrSpec("dark red", "default").layered_over(AttrSpec("yellow,bold", "dark blue", hyperlink="https://a.b"))
        AttrSpec('dark red', 'default', hyperlink=Hyperlink(uri='https://a.b', id=''))
        """
        link = self.__hyperlink if self.__hyperlink is not None else outer.hyperlink
        if not self.__value & _INHERIT_MASK:
            if link is self.__hyperlink:
                return self
            return AttrSpec(self.foreground, self.background, self.__color_mode(), hyperlink=link)
        fg = (outer if self.foreground_inherit else self).foreground.partition(",")[0]
        bg = outer.background if self.background_inherit else self.background
        own_settings = self.foreground.split(",")[1:]
        outer_settings = outer.foreground.split(",")[1:]
        settings = ""
        for name, off_name in zip(_ATTRIBUTES, _ATTRIBUTES_OFF, strict=True):
            # the inner attribute's own state, else the outer one's, else not mentioned
            for state in (own_settings, outer_settings):
                if name in state or off_name in state:
                    settings += f",{name}" if name in state else f",{off_name}"
                    break
        return AttrSpec(
            fg + settings,
            bg,
            max(self.colors, outer.colors) if colors is None else colors,
            hyperlink=link,
        )

    def __eq__(self, other: object) -> bool:
        """Return whether `other` is an :class:`AttrSpec` with the same underlying value and hyperlink."""
        return isinstance(other, AttrSpec) and self.__value == other._value and self.__hyperlink == other.hyperlink

    def __ne__(self, other: object) -> bool:
        """Return whether `other` is not equal to this :class:`AttrSpec`."""
        return not self == other


#: default RGB values substituted for a palette entry's 'default' foreground/background,
#: matching the black-on-light-gray terminal default used by the HTML-producing screens
_default_aspec = AttrSpec("black", "light gray")
_default_fg_rgb = _default_aspec.get_rgb_values()[:3]
_default_bg_rgb = _default_aspec.get_rgb_values()[3:]


def attr_spec_to_css(aspec: AttrSpec) -> tuple[str, str, str]:
    """Return the (foreground, background, extra CSS declarations) hex colors for *aspec*.

    Covers every :class:`AttrSpec` display setting a browser can render: color (falling back to
    the default black-on-light-gray for an unset foreground/background), ``standout`` (swaps
    foreground and background), ``underline``/``strikethrough`` (combined into one
    ``text-decoration``), ``bold``, ``italics``, ``blink`` (a step-start CSS animation, since the
    ``text-decoration:blink`` value browsers used to support has been dropped) and ``faint``.
    The hyperlink is not part of the style.
    """
    return _style_to_css(aspec.style_only())


@functools.lru_cache(maxsize=_RESOLVED_ATTRS_LIMIT)
def _style_to_css(aspec: AttrSpec) -> tuple[str, str, str]:
    """Return :func:`attr_spec_to_css` for an attribute without a hyperlink, cached per style."""
    fg_r, fg_g, fg_b, bg_r, bg_g, bg_b = aspec.get_rgb_values()
    if fg_r is None:
        fg_r, fg_g, fg_b = _default_fg_rgb
    if bg_r is None:
        bg_r, bg_g, bg_b = _default_bg_rgb
    fg = f"#{fg_r:02x}{fg_g:02x}{fg_b:02x}"
    bg = f"#{bg_r:02x}{bg_g:02x}{bg_b:02x}"
    if aspec.standout:
        fg, bg = bg, fg

    decoration = [name for name, on in (("underline", aspec.underline), ("line-through", aspec.strikethrough)) if on]

    extra = ""
    if decoration:
        extra += f";text-decoration:{' '.join(decoration)}"
    if aspec.bold:
        extra += ";font-weight:bold"
    if aspec.italics:
        extra += ";font-style:italic"
    if aspec.blink:
        extra += ";animation:urwid-blink 1s step-start infinite"
    if aspec.faint:
        extra += ";opacity:0.5"
    return fg, bg, extra


class RealTerminal:
    """Mixin providing access to the real terminal's signal key settings."""

    def __init__(self) -> None:
        """Initialize with no signal keys saved yet."""
        super().__init__()
        self._signal_keys_set = False
        self._old_signal_keys: tuple[bytes, bytes, bytes, bytes, bytes] | None = None

    if IS_WINDOWS:

        def tty_signal_keys(
            self,
            intr: Literal["undefined"] | int | bytes | None = None,
            quit: Literal["undefined"] | int | bytes | None = None,  # noqa: A002  # pylint: disable=redefined-builtin
            start: Literal["undefined"] | int | bytes | None = None,
            stop: Literal["undefined"] | int | bytes | None = None,
            susp: Literal["undefined"] | int | bytes | None = None,
            fileno: int | None = None,
        ) -> tuple[bytes, bytes, bytes, bytes, bytes] | None:
            r"""Read and/or set the tty's signal character settings.

            This function returns the current settings as a tuple of one-byte strings,
            as termios reports them, which may be passed back to restore them.

            Use the string 'undefined' to unmap keys from their signals.
            The value None is used when no change is being made.
            Setting signal keys is done using the integer ascii
            code for the key, eg.  3 for CTRL+C, or its one-byte string, eg. b"\x03".

            If this function is called after start() has been called
            then the original settings will be restored when stop()
            is called.
            """
            return None

    else:

        def tty_signal_keys(
            self,
            intr: Literal["undefined"] | int | bytes | None = None,
            quit: Literal["undefined"] | int | bytes | None = None,  # noqa: A002  # pylint: disable=redefined-builtin
            start: Literal["undefined"] | int | bytes | None = None,
            stop: Literal["undefined"] | int | bytes | None = None,
            susp: Literal["undefined"] | int | bytes | None = None,
            fileno: int | None = None,
        ) -> tuple[bytes, bytes, bytes, bytes, bytes] | None:
            r"""Read and/or set the tty's signal character settings.

            This function returns the current settings as a tuple of one-byte strings,
            as termios reports them, which may be passed back to restore them.

            Use the string 'undefined' to unmap keys from their signals.
            The value None is used when no change is being made.
            Setting signal keys is done using the integer ascii
            code for the key, eg.  3 for CTRL+C, or its one-byte string, eg. b"\x03".

            If this function is called after start() has been called
            then the original settings will be restored when stop()
            is called.
            """
            import termios

            if fileno is None:
                fileno = sys.stdin.fileno()
            if not os.isatty(fileno):
                return None

            tattr = termios.tcgetattr(fileno)
            sattr = tattr[6]
            skeys = (
                sattr[termios.VINTR],
                sattr[termios.VQUIT],
                sattr[termios.VSTART],
                sattr[termios.VSTOP],
                sattr[termios.VSUSP],
            )

            # termios reports these keys as bytes, and the tuple returned below is passed back
            # here to restore them, so check the type first: comparing bytes with str raises
            # BytesWarning under `python -bb`.
            if isinstance(intr, str) and intr == "undefined":
                intr = 0
            if isinstance(quit, str) and quit == "undefined":
                quit = 0  # noqa: A001
            if isinstance(start, str) and start == "undefined":
                start = 0
            if isinstance(stop, str) and stop == "undefined":
                stop = 0
            if isinstance(susp, str) and susp == "undefined":
                susp = 0

            if intr is not None:
                tattr[6][termios.VINTR] = intr
            if quit is not None:
                tattr[6][termios.VQUIT] = quit
            if start is not None:
                tattr[6][termios.VSTART] = start
            if stop is not None:
                tattr[6][termios.VSTOP] = stop
            if susp is not None:
                tattr[6][termios.VSUSP] = susp

            if any(item is not None for item in (intr, quit, start, stop, susp)):
                termios.tcsetattr(fileno, termios.TCSADRAIN, tattr)
                self._signal_keys_set = True

            return skeys


class ScreenError(Exception):
    """Raised for errors in :class:`BaseScreen` and its subclasses."""


class PaletteEntrySpecs(typing.NamedTuple):
    """The specifications one palette entry is drawn with, one per number of colors.

    The position of each field is the index :meth:`BaseScreen.resolve_attr` takes.
    """

    #: 16 colors
    basic: AttrSpec
    #: monochrome
    mono: AttrSpec
    #: 88 colors
    high_88: AttrSpec
    #: 256 colors
    high_256: AttrSpec
    #: true color
    high_true: AttrSpec


class InputClosedError(RuntimeError):
    """Raised when the screen's input reaches end of file.

    A terminal that hangs up is one cause.
    It is a :exc:`RuntimeError`, so a handler that catches :exc:`RuntimeError` around :meth:`MainLoop.run` catches it
    too.
    """


class BaseScreen(abc.ABC, metaclass=signals.MetaSignals):
    """Base class for Screen classes (display.raw.Screen, ..., etc.)."""

    signals: typing.ClassVar[list[str]] = [UPDATE_PALETTE_ENTRY, INPUT_DESCRIPTORS_CHANGED]

    def __init__(self) -> None:
        """Initialize an unstarted screen with an empty palette."""
        super().__init__()

        self.logger = logging.getLogger(f"{self.__class__.__module__}.{self.__class__.__name__}")

        self._palette: dict[Hashable, PaletteEntrySpecs] = {}
        self._resolved_attrs: dict[tuple[Hashable, int], AttrSpec] = {}
        self._started: bool = False

    @property
    def started(self) -> bool:
        """Return whether the screen has been started and not yet stopped."""
        return self._started

    @property
    def palette(self) -> Mapping[Hashable, PaletteEntrySpecs]:
        """Return a read-only view of the registered palette entries.

        The view follows later changes to the palette.
        Change the palette with :meth:`register_palette` and :meth:`register_palette_entry`.

        >>> from urwid.display.html_fragment import HtmlGenerator
        >>> screen = HtmlGenerator()
        >>> screen.register_palette_entry("title", "white", "dark blue")
        >>> screen.palette["title"].basic
        AttrSpec('white', 'dark blue')

        :returns: per entry name, the specifications it is drawn with; ``None`` names the default attribute.
        """
        return types.MappingProxyType(self._palette)

    def start(self, *args: typing.Any, **kwargs: typing.Any) -> StoppingContext:
        """Set up the screen.

        If the screen has already been started, does nothing.

        May be used as a context manager, in which case :meth:`stop` will
        automatically be called at the end of the block:

            with screen.start():
                ...

        You shouldn't override this method in a subclass; instead, override
        :meth:`_start`.
        """
        if not self._started:
            self._started = True
            self._start(*args, **kwargs)
        return StoppingContext(self)

    def _start(self, *args: typing.Any, **kwargs: typing.Any) -> None:
        """Perform the actual setup of the screen. Subclasses should override this method."""

    def stop(self) -> None:
        """Tear down the screen if it has been started.

        Emits ``INPUT_DESCRIPTORS_CHANGED`` once the screen is marked stopped,
        so an event loop hooked to the screen stops watching its input.

        You shouldn't override this method; override :meth:`_stop`.
        """
        if not self._started:
            return
        self._stop()
        self._started = False
        signals.emit_signal(self, INPUT_DESCRIPTORS_CHANGED)

    def _stop(self) -> None:
        """Perform actual teardown of the screen. Subclasses should override this method."""

    def set_mouse_tracking(self, enable: bool = True) -> None:
        """Enable or disable tracking of mouse movement events. A no-op here; subclasses override it."""

    @abc.abstractmethod
    def draw_screen(self, size: tuple[int, int], canvas: Canvas) -> None:
        """Draw *canvas* of the given *size* to the screen. Subclasses must implement this method."""

    def clear(self) -> None:
        """Clear the screen if possible.

        Force the screen to be completely repainted on the next call to draw_screen().
        """

    def get_cols_rows(self) -> tuple[int, int]:
        """Return the terminal dimensions (num columns, num rows).

        Default (fallback) is 80x24.
        """
        return 80, 24

    def register_palette(self, palette: Iterable[PaletteEntry], *, replace: bool = False) -> None:
        """Register a set of palette entries.

        With *replace*, the entries that *palette* does not name are removed once all of its entries are registered.
        A removed name is drawn in the terminal's default colors, as a name that was never registered is.
        The ``None`` entry is kept unless *palette* names it, so the screen keeps its default attribute.

        >>> from urwid.display.html_fragment import HtmlGenerator
        >>> screen = HtmlGenerator()
        >>> screen.register_palette([("title", "white", "dark blue"), ("body", "black", "light gray")])
        >>> screen.register_palette([("body", "white", "black")], replace=True)
        >>> list(screen.palette)
        [None, 'body']

        :param palette: a list of (name, like_other_name) or
            (name, foreground, background, mono, foreground_high, background_high) tuples
        :param replace: remove the entries that *palette* does not name
        :raises ScreenError: an entry is neither a 2-, 3-, 4- nor 6-tuple, or copies a name that is not registered yet.
            The entries before it stay registered, and with *replace* no entry is removed.

            The (name, like_other_name) format will copy the settings
            from the palette entry like_other_name, which must appear
            before this tuple in the list.

            The mono and foreground/background_high values are
            optional ie. the second tuple format may have 3, 4 or 6
            values.  See register_palette_entry() for a description
            of the tuple values.
        """
        names: set[Hashable] = {None}
        for item in palette:
            if len(item) in {3, 4, 6}:
                # pyrefly: ignore[bad-argument-type]  # a union of tuples of different lengths
                self.register_palette_entry(*item)
                names.add(item[0])
                continue
            if len(item) != 2:
                raise ScreenError(f"Invalid register_palette entry: {item!r}")
            name, like_name = item
            if like_name not in self._palette:
                raise ScreenError(f"palette entry '{like_name}' doesn't exist")
            signals.emit_signal(self, UPDATE_PALETTE_ENTRY, name, *self._palette[like_name])
            self._palette[name] = self._palette[like_name]
            self._resolved_attrs.clear()
            names.add(name)
        if not replace:
            return
        removed = [name for name in self._palette if name not in names]
        if not removed:
            return
        # what a removed name is drawn with from now on, sent so that displays caching per name draw it again
        default_specs = PaletteEntrySpecs(
            *(AttrSpec(DEFAULT, DEFAULT, colors) for colors in (16, 1, 88, 256, 16777216))
        )
        for name in removed:
            signals.emit_signal(self, UPDATE_PALETTE_ENTRY, name, *default_specs)
            del self._palette[name]
            self._resolved_attrs.clear()

    def register_palette_entry(
        self,
        name: Hashable,
        foreground: str,
        background: str,
        mono: str | tuple[str, ...] | None = None,
        foreground_high: str | None = None,
        background_high: str | None = None,
    ) -> None:
        """Register a single palette entry.

        :param name: new entry/attribute name, any hashable value; ``None`` names the default attribute

        :param foreground: a string containing a comma-separated foreground
            color and settings

            Color values:
            'default' (use the terminal's default foreground),
            'inherit' (take the color from the enclosing attribute),
            'black', 'dark red', 'dark green', 'brown', 'dark blue',
            'dark magenta', 'dark cyan', 'light gray', 'dark gray',
            'light red', 'light green', 'yellow', 'light blue',
            'light magenta', 'light cyan', 'white'

            Settings:
            'bold', 'underline', 'blink', 'standout', 'strikethrough'

            Some terminals use 'bold' for bright colors.  Most terminals
            ignore the 'blink' setting.  If the color is not given then
            'default' will be assumed.

        :param background: a string containing the background color

            Background color values:
            'default' (use the terminal's default background),
            'inherit' (take the color from the enclosing attribute),
            'black', 'dark red', 'dark green', 'brown', 'dark blue',
            'dark magenta', 'dark cyan', 'light gray'

        :param mono: a comma-separated string containing monochrome terminal
            settings (see "Settings" above.)

            None = no terminal settings (same as 'default')

        :param foreground_high: a string containing a comma-separated
            foreground color and settings, standard foreground
            colors (see "Color values" above) or high-colors may
            be used

            High-color example values:
            '#009' (0% red, 0% green, 60% red, like HTML colors)
            '#fcc' (100% red, 80% green, 80% blue)
            'g40' (40% gray, decimal), 'g#cc' (80% gray, hex),
            '#000', 'g0', 'g#00' (black),
            '#fff', 'g100', 'g#ff' (white)
            'h8' (color number 8), 'h255' (color number 255)

            None = use foreground parameter value

        :param background_high: a string containing the background color,
            standard background colors (see "Background colors" above)
            or high-colors (see "High-color example values" above)
            may be used

            None = use background parameter value
        """
        basic = AttrSpec(foreground, background, 16)

        if isinstance(mono, tuple):
            # old style of specifying mono attributes was to put them in a tuple.  convert to comma-separated string
            mono = ",".join(mono)
        if mono is None:
            mono = DEFAULT
        if basic.foreground_inherit or basic.background_inherit:
            # monochrome has no colors to inherit, but the settings are combined the same way
            mono_settings = [part for part in mono.split(",") if part.strip() not in _DEFAULT_COLOR_NAMES]
            mono_spec = AttrSpec(
                ",".join((INHERIT if basic.foreground_inherit else DEFAULT, *mono_settings)),
                INHERIT if basic.background_inherit else DEFAULT,
                1,
            )
        else:
            mono_spec = AttrSpec(mono, DEFAULT, 1)

        if foreground_high is None:
            foreground_high = foreground
        if background_high is None:
            background_high = background

        high_256 = AttrSpec(foreground_high, background_high, 256)
        high_true = AttrSpec(foreground_high, background_high, 16777216)  # 2**24 is not Literal

        # 'hX' where X > 15 are different in 88/256 color, use
        # basic colors for 88-color mode if high colors are specified
        # in this way (also avoids crash when X > 87)
        def large_h(desc: str) -> bool:
            if not desc.startswith("h"):
                return False
            if "," in desc:
                desc = desc.split(",", 1)[0]
            num = int(desc[1:], 10)
            return num > 15

        if large_h(foreground_high) or large_h(background_high):
            high_88 = basic
        else:
            high_88 = AttrSpec(foreground_high, background_high, 88)

        entry = PaletteEntrySpecs(basic, mono_spec, high_88, high_256, high_true)
        signals.emit_signal(self, UPDATE_PALETTE_ENTRY, name, *entry)
        self._palette[name] = entry
        self._resolved_attrs.clear()

    def resolve_attr(self, attr: Hashable, index: int) -> AttrSpec:
        """Return the :class:`AttrSpec` to draw a canvas run with display attribute *attr*.

        Starting from the palette entry of ``None``, each layer of *attr* (a palette name, an :class:`AttrSpec`
        or a :class:`LayeredAttr`), outermost first, is placed over the result so far with
        :meth:`AttrSpec.layered_over`. A name missing from the palette is drawn with 'default' colors,
        hiding the layers under it.

        :param attr: display attribute of a canvas run
        :param index: position in the palette entry tuple: 0 for 16 colors, 1 for monochrome,
            2 for 88 colors, 3 for 256 colors, 4 for true color
        :raises IndexError: *index* is outside 0-4 and a layer is a palette name.
        """
        key = (attr, index)
        if (found := self._resolved_attrs.get(key)) is not None:
            return found
        if isinstance(attr, LayeredAttr):
            layers: tuple[Hashable, ...] = (*attr.layers, None)
        elif attr is None:
            layers = (None,)
        else:
            layers = (attr, None)
        result: AttrSpec | None = None
        for layer in reversed(layers):
            if isinstance(layer, AttrSpec):
                spec = layer
            elif (entry := self._palette.get(layer)) is not None:
                spec = entry[index]
            elif layer is None:
                continue
            else:
                self.logger.debug(f"Undefined attribute: {layer!r}")
                spec = AttrSpec(DEFAULT, DEFAULT)
            # 88-color numbers differ from 256-color ones, so an 88-color screen keeps its own encoding
            result = spec if result is None else spec.layered_over(result, colors=88 if index == 2 else None)
        if result is None:
            result = AttrSpec(DEFAULT, DEFAULT)
        if len(self._resolved_attrs) >= _RESOLVED_ATTRS_LIMIT:
            self._resolved_attrs.clear()
        self._resolved_attrs[key] = result
        return result


def _test() -> None:
    import doctest

    doctest.testmod()


if __name__ == "__main__":
    _test()
