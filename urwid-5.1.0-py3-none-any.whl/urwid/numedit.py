#
# Urwid basic widget classes
#    Copyright (C) 2004-2012  Ian Ward
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/


"""Edit widgets that accept only integer or decimal numbers."""

from __future__ import annotations

import decimal
import operator
import re
import sys
import typing

from urwid import Edit, _deprecation
from urwid.command_map import Command

if typing.TYPE_CHECKING:
    from collections.abc import Container

    from urwid.util import _TagMarkup


class NumEdit(Edit):
    """NumEdit - edit numerical types.

    based on the characters in 'allowed' different numerical types
    can be edited:
      + regular int: 0123456789
      + regular float: 0123456789.
      + regular oct: 01234567
      + regular hex: 0123456789abcdef
    """

    ALLOWED = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def __init__(
        self,
        allowed: Container[str],
        caption: _TagMarkup,
        default: str,
        trimLeadingZeros: bool | None = None,
        *,
        trim_leading_zeros: bool = True,
        allow_negative: bool = False,
    ) -> None:
        """Initialize a numeric edit widget restricted to the given set of characters.

        :param allowed: characters accepted by this widget
        :param caption: caption markup
        :param default: default edit value
        :param trimLeadingZeros: legacy spelling of ``trim_leading_zeros``
        :param trim_leading_zeros: strip leading zeros from the edit value
        :param allow_negative: accept a leading minus sign

        .. deprecated:: 2.2.3
            The ``trimLeadingZeros`` argument is deprecated, use the ``trim_leading_zeros``
            keyword argument instead. The argument will be removed in version 7.0.
        """
        super().__init__(caption, default)
        self._allowed = allowed
        self._trim_leading_zeros = trim_leading_zeros
        self._allow_negative = allow_negative

        if trimLeadingZeros is not None:
            _deprecation.warn(
                "'trimLeadingZeros' argument is deprecated. Use 'trim_leading_zeros' keyword argument.",
                since="2.2.3",
                removed_in="7.0",
            )
            self._trim_leading_zeros = trimLeadingZeros

    def valid_char(self, ch: str) -> bool:
        """Return true for allowed characters."""
        if len(ch) == 1:
            if ch.upper() in self._allowed:
                return True

            return self._allow_negative and ch == "-" and self.edit_pos == 0 and "-" not in self.edit_text
        return False

    def _valid_insert(self, text: str | bytes, result_text: str | bytes) -> bool:
        """Return whether *result_text* is allowed characters, after one leading ``-`` with *allow_negative*."""
        if self._allow_negative and result_text[:1] == "-":
            result_text = result_text[1:]
        return all(char.upper() in self._allowed for char in typing.cast("str", result_text))

    def keypress(
        self,
        size: tuple[int],  # type: ignore[override]
        key: str,
    ) -> str | None:
        """
        Handle editing keystrokes.  Remove leading zeros.

        >>> e, size = NumEdit("0123456789", "", "5002"), (10,)
        >>> e.keypress(size, "home")
        >>> e.keypress(size, "delete")
        >>> assert e.edit_text == "002"
        >>> e.keypress(size, "end")
        >>> assert e.edit_text == "2"
        >>> # binary only
        >>> e, size = NumEdit("01", "", ""), (10,)
        >>> assert e.edit_text == ""
        >>> e.keypress(size, "1")
        >>> e.keypress(size, "0")
        >>> e.keypress(size, "1")
        >>> assert e.edit_text == "101"
        >>> e, size = NumEdit("0123456789", "", "", allow_negative=True), (10,)
        >>> e.keypress(size, "-")
        >>> e.keypress(size, "1")
        >>> e.edit_text
        '-1'
        >>> e.keypress(size, "home")
        >>> e.keypress(size, "delete")
        >>> e.edit_text
        '1'
        >>> e.keypress(size, "end")
        >>> e.keypress(size, "-")
        '-'
        >>> e.edit_text
        '1'
        """
        with self._editing():  # the trim belongs to the undo step of the key
            unhandled = super().keypress(size, key)

            # a restored state is kept as it was shown
            restored = self._command_map[key] in {Command.UNDO, Command.REDO}
            if not unhandled and not restored and self._trim_leading_zeros:
                # trim leading zeros after the sign, but keep the zero of "0" and "0.5"
                sign = int(self.edit_text.startswith("-"))
                while (
                    self.edit_pos > sign
                    and self.edit_text[sign : sign + 1] == "0"
                    and self.edit_text[sign + 1 : sign + 2].isalnum()
                ):
                    self.set_edit_pos(self.edit_pos - 1)
                    self.set_edit_text(self.edit_text[:sign] + self.edit_text[sign + 1 :])

        return unhandled


class IntegerEdit(NumEdit):
    """Edit widget for integer values."""

    def __init__(
        self,
        caption: _TagMarkup = "",
        default: int | str | decimal.Decimal | None = None,
        base: int = 10,
        *,
        allow_negative: bool = False,
    ) -> None:
        """Initialize an edit widget restricted to integer values.

        :param caption: caption markup
        :param default: numeric initial value, or a string of digits in the selected base
        :param base: the numeric base of the value, from 2 to 36
        :param allow_negative: accept a negative default and a leading minus sign in input
        :raises TypeError: *base* is not an integer.
        :raises ValueError: *base* is outside 2 to 36.
            *default* is not an ``int``, ``str`` or integral :class:`decimal.Decimal`, does not consist of digits
            valid for *base*, is negative without *allow_negative*, or has more digits than
            :func:`sys.get_int_max_str_digits` allows.

        >>> IntegerEdit("", 42)
        <IntegerEdit selectable flow widget '42' edit_pos=2>
        >>> e, size = IntegerEdit("", "5002"), (10,)
        >>> e.keypress(size, "home")
        >>> e.keypress(size, "delete")
        >>> assert e.edit_text == "002"
        >>> e.keypress(size, "end")
        >>> assert e.edit_text == "2"
        >>> e.keypress(size, "9")
        >>> e.keypress(size, "0")
        >>> assert e.edit_text == "290"
        >>> e, size = IntegerEdit("", ""), (10,)
        >>> assert e.value() is None
        >>> # binary
        >>> e, size = IntegerEdit("", "1010", base=2), (10,)
        >>> e.keypress(size, "end")
        >>> e.keypress(size, "1")
        >>> assert e.edit_text == "10101"
        >>> assert e.value() == decimal.Decimal("21")
        >>> # HEX
        >>> e, size = IntegerEdit("", "10", base=16), (10,)
        >>> e.keypress(size, "end")
        >>> e.keypress(size, "F")
        >>> e.keypress(size, "f")
        >>> assert e.edit_text == "10Ff"
        >>> assert e.keypress(size, "G") == "G"  # unhandled key
        >>> assert e.edit_text == "10Ff"
        >>> # keep leading 0's when not base 10
        >>> e, size = IntegerEdit("", "10FF", base=16), (10,)
        >>> assert e.edit_text == "10FF"
        >>> assert e.value() == decimal.Decimal("4351")
        >>> e.keypress(size, "home")
        >>> e.keypress(size, "delete")
        >>> e.keypress(size, "0")
        >>> assert e.edit_text == "00FF"
        >>> # test exception on incompatible value for base
        >>> e, size = IntegerEdit("", "10FG", base=16), (10,)
        Traceback (most recent call last):
            ...
        ValueError: invalid value: 10FG for base 16
        >>> # test exception on float init value
        >>> e, size = IntegerEdit("", 10.0), (10,)
        Traceback (most recent call last):
            ...
        ValueError: default: Only 'str', 'int' or Decimal input allowed
        >>> e, size = IntegerEdit("", decimal.Decimal("10.0")), (10,)
        Traceback (most recent call last):
            ...
        ValueError: not an 'integer Decimal' instance
        """
        base = operator.index(base)
        if not 2 <= base <= 36:
            raise ValueError(f"invalid base: {base}; expected a value from 2 to 36")
        self.base = base
        val = ""
        allowed_chars = self.ALLOWED[: self.base]
        if default is not None:
            if isinstance(default, bool) or not isinstance(default, (int, str, decimal.Decimal)):
                raise ValueError("default: Only 'str', 'int' or Decimal input allowed")

            if isinstance(default, str):
                digits = default[1:] if allow_negative and default.startswith("-") else default
                if default and not re.fullmatch(f"[{allowed_chars}]+", digits, re.IGNORECASE):
                    raise ValueError(f"invalid value: {default} for base {base}")
                val = default

            else:
                if isinstance(default, decimal.Decimal):
                    # NaN and infinity have a str exponent; a negative exponent is a fractional part, even "10.0"
                    exponent = default.as_tuple().exponent
                    if not isinstance(exponent, int) or exponent < 0:
                        raise ValueError("not an 'integer Decimal' instance")
                    # int() would build the whole value of a huge exponent before str() below can refuse it
                    max_digits = sys.get_int_max_str_digits()
                    # adjusted() of a zero is its exponent, so Decimal("0E+5000") is skipped as the zero it is
                    if max_digits and default and default.adjusted() >= max_digits:
                        raise ValueError(f"default has more than {max_digits} digits")

                number = int(default)
                if number < 0 and not allow_negative:
                    raise ValueError(f"invalid value: {default} for base {base}")

                # str() refuses a value over sys.get_int_max_str_digits() at once, so the loop below stays short
                decimal_text = str(number)
                if base == 10:
                    val = decimal_text
                else:
                    sign = "-" if number < 0 else ""
                    number = abs(number)
                    converted_digits = []
                    while number:
                        number, remainder = divmod(number, base)
                        converted_digits.append(self.ALLOWED[remainder])
                    val = sign + ("".join(reversed(converted_digits)) or "0")

            if val:
                # fail here rather than in value(): int() refuses digit strings over sys.get_int_max_str_digits()
                int(val, base)

        super().__init__(
            allowed_chars,
            caption,
            val,
            trim_leading_zeros=(self.base == 10),
            allow_negative=allow_negative,
        )

    def value(self) -> decimal.Decimal | None:
        """
        Return the numeric value of self.edit_text.

        >>> e, size = IntegerEdit(), (10,)
        >>> e.keypress(size, "5")
        >>> e.keypress(size, "1")
        >>> assert e.value() == 51
        """
        if self.edit_text:
            return decimal.Decimal(int(self.edit_text, self.base))

        return None

    def __int__(self) -> int:
        """Enforced int value return.

        >>> e, size = IntegerEdit(allow_negative=True), (10,)
        >>> assert int(e) == 0
        >>> e.keypress(size, "-")
        >>> e.keypress(size, "4")
        >>> e.keypress(size, "2")
        >>> assert int(e) == -42
        """
        if self.edit_text:
            return int(self.edit_text, self.base)
        return 0


class FloatEdit(NumEdit):
    """Edit widget for float values."""

    def __init__(
        self,
        caption: _TagMarkup = "",
        default: str | int | decimal.Decimal | None = None,
        preserveSignificance: bool | None = None,
        decimalSeparator: str | None = None,
        *,
        preserve_significance: bool = True,
        decimal_separator: str = ".",
        allow_negative: bool = False,
    ) -> None:
        """Initialize a decimal edit widget.

        :param caption: caption markup
        :param default: default edit value. Strings must use the configured decimal separator.
        :param preserveSignificance: deprecated positional form of *preserve_significance*
        :param decimalSeparator: deprecated positional form of *decimal_separator*
        :param preserve_significance: return value has the same signif. as default
        :param decimal_separator: use '.' as separator by default, optionally a ','
        :param allow_negative: accept a leading minus sign in string defaults and input
        :raises ValueError: *default* is not an ``int``, ``str`` or :class:`decimal.Decimal`.
            *default* is a string with the other decimal separator, is not a number, or is not a finite value.
            *decimal_separator* is neither ``'.'`` nor ``','``.

        .. deprecated:: 2.2.3
            The ``preserveSignificance`` and ``decimalSeparator`` arguments are deprecated,
            use the ``preserve_significance`` and ``decimal_separator`` keyword arguments instead.
            The arguments will be removed in version 7.0.

        >>> FloatEdit("", "1.065434")
        <FloatEdit selectable flow widget '1.065434' edit_pos=8>
        >>> e, size = FloatEdit("", "1.065434"), (10,)
        >>> e.keypress(size, "home")
        >>> e.keypress(size, "delete")
        >>> assert e.edit_text == ".065434"
        >>> e.keypress(size, "end")
        >>> e.keypress(size, "backspace")
        >>> assert e.edit_text == ".06543"
        >>> e, size = FloatEdit(), (10,)
        >>> e.keypress(size, "5")
        >>> e.keypress(size, "1")
        >>> e.keypress(size, ".")
        >>> e.keypress(size, "5")
        >>> e.keypress(size, "1")
        >>> assert e.value() == decimal.Decimal("51.51"), e.value()
        >>> e, size = FloatEdit(decimal_separator=":"), (10,)
        Traceback (most recent call last):
            ...
        ValueError: invalid decimal separator: :
        >>> e, size = FloatEdit(decimal_separator=","), (10,)
        >>> e.keypress(size, "5")
        >>> e.keypress(size, "1")
        >>> e.keypress(size, ",")
        >>> e.keypress(size, "5")
        >>> e.keypress(size, "1")
        >>> assert e.edit_text == "51,51"
        >>> e, size = FloatEdit("", "3.1415", preserve_significance=True), (10,)
        >>> e.keypress(size, "end")
        >>> e.keypress(size, "backspace")
        >>> e.keypress(size, "backspace")
        >>> assert e.edit_text == "3.14"
        >>> assert e.value() == decimal.Decimal("3.1400")
        >>> e.keypress(size, "1")
        >>> e.keypress(size, "5")
        >>> e.keypress(size, "9")
        >>> assert e.value() == decimal.Decimal("3.1416"), e.value()
        >>> e, size = FloatEdit("", ""), (10,)
        >>> assert e.value() is None
        >>> e, size = FloatEdit("", 10.0), (10,)
        Traceback (most recent call last):
            ...
        ValueError: default: Only 'str', 'int' or Decimal input allowed
        """
        self.significance: decimal.Decimal | None = None
        self._decimal_separator = decimal_separator
        if decimalSeparator is not None:
            _deprecation.warn(
                "'decimalSeparator' argument is deprecated. Use 'decimal_separator' keyword argument.",
                since="2.2.3",
                removed_in="7.0",
            )
            self._decimal_separator = decimalSeparator

        if self._decimal_separator not in {".", ","}:
            raise ValueError(f"invalid decimal separator: {self._decimal_separator}")

        if preserveSignificance is not None:
            _deprecation.warn(
                "'preserveSignificance' argument is deprecated. Use 'preserve_significance' keyword argument.",
                since="2.2.3",
                removed_in="7.0",
            )
            preserve_significance = preserveSignificance

        val = ""
        if default is not None and default != "":  # noqa: PLC1901,RUF100
            if not isinstance(default, (int, str, decimal.Decimal)):
                raise ValueError("default: Only 'str', 'int' or Decimal input allowed")

            if isinstance(default, str) and default:
                # check if it is a float, raises a ValueError otherwise
                invalid_separator = "," if self._decimal_separator == "." else "."
                if invalid_separator in default:
                    raise ValueError(f"invalid decimal separator in default value: {invalid_separator}")
                default = default.replace(self._decimal_separator, ".")
                float(default)
                default = decimal.Decimal(default)

            if isinstance(default, decimal.Decimal) and not default.is_finite():
                raise ValueError("default: must be a finite decimal value")

            if preserve_significance and isinstance(default, decimal.Decimal):
                self.significance = default

            val = format(default, "f") if isinstance(default, decimal.Decimal) else str(default)
            val = val.replace(".", self._decimal_separator)

        super().__init__(self.ALLOWED[0:10] + self._decimal_separator, caption, val, allow_negative=allow_negative)

    def valid_char(self, ch: str) -> bool:
        """Return true for allowed characters, refusing a second decimal separator."""
        if ch == self._decimal_separator and ch in self.edit_text:
            return False
        return super().valid_char(ch)

    def _valid_insert(self, text: str | bytes, result_text: str | bytes) -> bool:
        """Return whether *result_text* is allowed characters with at most one decimal separator."""
        return typing.cast("str", result_text).count(self._decimal_separator) <= 1 and super()._valid_insert(
            text, result_text
        )

    def value(self) -> decimal.Decimal | None:
        """Return the numeric value of self.edit_text."""
        if self.edit_text:
            normalized = decimal.Decimal(self.edit_text.replace(self._decimal_separator, "."))
            if self.significance is not None:
                normalized_tuple = normalized.as_tuple()
                significance_tuple = self.significance.as_tuple()
                # as_tuple().exponent is typed as a union with the non-finite
                # markers; derive both exponents from adjusted() instead, which
                # is always a plain int: exponent == adjusted() - len(digits) + 1.
                normalized_exponent = normalized.adjusted() - len(normalized_tuple.digits) + 1
                significance_exponent = self.significance.adjusted() - len(significance_tuple.digits) + 1
                precision = max(
                    len(normalized_tuple.digits) + max(0, normalized_exponent - significance_exponent),
                    len(significance_tuple.digits),
                )
                with decimal.localcontext() as context:
                    context.prec = max(context.prec, precision)
                    return normalized.quantize(self.significance)
            return normalized

        return None

    def __float__(self) -> float:
        """Enforced float value return.

        >>> e, size = FloatEdit(allow_negative=True), (10,)
        >>> assert float(e) == 0.0
        >>> e.keypress(size, "-")
        >>> e.keypress(size, "4")
        >>> e.keypress(size, ".")
        >>> e.keypress(size, "2")
        >>> assert float(e) == -4.2
        """
        if self.edit_text:
            return float(self.edit_text.replace(self._decimal_separator, "."))
        return 0.0
