# Urwid graphics widgets
#    Copyright (C) 2004-2011  Ian Ward
#
#    This library is free software; you can redistribute it and/or
#    modify it under the terms of the GNU Lesser General Public
#    License as published by the Free Software Foundation; either
#    version 2.1 of the License, or (at your option) any later version.
#
#    This library is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this library; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Urwid web site: https://urwid.org/


"""The PythonLogo widget, and graphics widgets re-exported from :mod:`urwid.widget`."""

from __future__ import annotations

import typing

from urwid.display import AttrSpec
from urwid.widget import (
    Sizing,
    Text,
    Widget,
    fixed_size,
)

if typing.TYPE_CHECKING:
    from urwid import canvas

__all__ = ("PythonLogo",)


class PythonLogo(Widget):
    """Fixed widget that draws an ASCII-art rendering of the Python logo."""

    _sizing = frozenset([Sizing.FIXED])

    def __init__(self) -> None:
        """Create canvas containing an ASCII version of the Python Logo and store it."""
        super().__init__()
        blu = AttrSpec("light blue", "default")
        yel = AttrSpec("yellow", "default")
        width = 17
        # fmt: off
        self._canvas: canvas.TextCanvas = Text(
            [
                (blu, "     ______\n"),
                (blu, "   _|_o__  |"), (yel, "__\n"),
                (blu, "  |   _____|"), (yel, "  |\n"),
                (blu, "  |__|  "), (yel, "______|\n"),
                (yel, "     |____o_|"),
            ]
        ).render((width,))
        # fmt: on

    def pack(self, size: tuple[()] | None = None, focus: bool = False) -> tuple[int, int]:  # type: ignore[override]
        """Return the size from our pre-rendered canvas."""
        return self._canvas.cols(), self._canvas.rows()

    def render(self, size: tuple[()], focus: bool = False) -> canvas.TextCanvas:  # type: ignore[override]
        """Return the pre-rendered canvas."""
        fixed_size(size)
        return self._canvas


def _test() -> None:
    import doctest

    doctest.testmod()


if __name__ == "__main__":
    _test()
