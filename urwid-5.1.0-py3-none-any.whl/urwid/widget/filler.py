"""Filler: a decoration that lets a flow widget be used as a box widget."""

from __future__ import annotations

import typing
import warnings

from urwid.canvas import CompositeCanvas
from urwid.split_repr import remove_defaults
from urwid.util import int_scale

from .constants import (
    RELATIVE_100,
    Sizing,
    VAlign,
    WHSettings,
    normalize_height,
    normalize_valign,
    simplify_height,
    simplify_valign,
)
from .widget import _InvalidatingAttribute
from .widget_decoration import WidgetDecoration, WidgetError, WidgetWarning

if typing.TYPE_CHECKING:
    from typing import Literal

    from .constants import Align
    from .widget import AbstractFlowWidget, AbstractWidget

WrappedWidget = typing.TypeVar("WrappedWidget", bound="AbstractWidget")


class FillerError(WidgetError):
    """Filler related errors."""


class FillerWarning(WidgetWarning):
    """Filler related warnings."""


class Filler(WidgetDecoration[WrappedWidget]):
    """Box widget decoration that vertically aligns a flow or box widget within the available space."""

    #: Number of blank rows above the body.
    top = _InvalidatingAttribute[int]()
    #: Number of blank rows below the body.
    bottom = _InvalidatingAttribute[int]()
    #: Minimum height of the body for a relative height, or ``None`` for no minimum.
    min_height = _InvalidatingAttribute[int | None]()

    def __init__(
        self,
        body: WrappedWidget,
        valign: (
            Literal["top", "middle", "bottom"]
            | VAlign
            | tuple[Literal["relative", "fixed top", "fixed bottom", WHSettings.RELATIVE], int]
        ) = VAlign.MIDDLE,
        height: (
            int
            | Literal["pack", WHSettings.PACK]
            | tuple[Literal["relative", "fixed top", "fixed bottom", WHSettings.RELATIVE], int]
            | None
        ) = WHSettings.PACK,
        min_height: int | None = None,
        top: int = 0,
        bottom: int = 0,
    ) -> None:
        """
        :param body: a flow widget or box widget to be filled around (stored as self.original_widget)

        :param valign: one of:
            ``'top'``, ``'middle'``, ``'bottom'``,
            (``'relative'``, *percentage* 0=top 100=bottom)

        :param height: one of:

            ``'pack'``
              if body is a flow widget

            *given height*
              integer number of rows for self.original_widget

            (``'relative'``, *percentage of total height*)
              make height depend on container's height

        :param min_height: one of:

            ``None``
              if no minimum or if body is a flow widget

            *minimum height*
              integer number of rows for the widget when height not fixed

        :param top: a fixed number of rows to fill at the top
        :param bottom: a fixed number of rows to fill at the bottom
        :raises FillerError: *valign* is not a vertical alignment value, or a fixed height is combined with a valign it
            cannot be used with.

        If body is a flow widget, then height must be ``'pack'`` and *min_height* will be ignored.
        Sizing of the filler will be BOX/FLOW in this case.

        If height is integer, *min_height* will be ignored and sizing of filler will be BOX/FLOW.

        Filler widgets will try to satisfy height argument first by reducing the valign amount when necessary.
        If height still cannot be satisfied it will also be reduced.
        """
        super().__init__(body)

        # convert old parameters to the new top/bottom values
        normalized_height: int | Literal["pack", WHSettings.PACK] | tuple[Literal["relative", WHSettings.RELATIVE], int]
        if isinstance(height, tuple):
            if height[0] == "fixed top":
                if not isinstance(valign, tuple) or valign[0] != "fixed bottom":
                    raise FillerError("fixed top height may only be used with fixed bottom valign")
                top = height[1]
                normalized_height = RELATIVE_100
            elif height[0] == "fixed bottom":
                if not isinstance(valign, tuple) or valign[0] != "fixed top":
                    raise FillerError("fixed bottom height may only be used with fixed top valign")
                bottom = height[1]
                normalized_height = RELATIVE_100
            else:
                # 'fixed top'/'fixed bottom' handled above, so only the relative form remains.
                normalized_height = typing.cast("tuple[Literal['relative', WHSettings.RELATIVE], int]", height)

        # convert old flow mode parameters height=None and height='flow' to height='pack'
        elif height is None or height in {Sizing.FLOW, WHSettings.PACK}:  # 'pack' used to be called 'flow'
            normalized_height = WHSettings.PACK  # pylint: disable=redefined-variable-type  # declared union type

        else:
            normalized_height = height

        normalized_valign: VAlign | tuple[Literal["relative", WHSettings.RELATIVE], int]
        if isinstance(valign, tuple):
            if valign[0] == "fixed top":
                top = valign[1]
                normalized_valign = VAlign.TOP
            elif valign[0] == "fixed bottom":
                bottom = valign[1]
                normalized_valign = VAlign.BOTTOM
            else:
                # 'fixed top'/'fixed bottom' handled above, so only the relative form remains.
                normalized_valign = typing.cast("tuple[Literal['relative', WHSettings.RELATIVE], int]", valign)

        elif not isinstance(valign, (VAlign, str)):
            raise FillerError(f"invalid valign: {valign!r}")

        else:
            normalized_valign = VAlign(valign)  # pylint: disable=redefined-variable-type  # declared union type

        self.top = top
        self.bottom = bottom
        self.valign_type: Literal[WHSettings.RELATIVE] | VAlign
        self.valign_amount: int | None
        self.height_type: Literal[WHSettings.PACK, WHSettings.GIVEN, WHSettings.RELATIVE]
        self.height_amount: int | None
        self.valign_type, self.valign_amount = normalize_valign(normalized_valign, FillerError)
        self.height_type, self.height_amount = normalize_height(normalized_height, FillerError)

        if self.height_type not in {WHSettings.GIVEN, WHSettings.PACK}:
            self.min_height = min_height
        else:
            self.min_height = None

    def sizing(self) -> frozenset[Sizing]:
        """Widget sizing.

        Sizing BOX is always supported.
        Sizing FLOW is supported if: FLOW widget (a height type is PACK) or BOX widget with height GIVEN

        Rules:
        * height == PACK: the height is taken from the wrapped widget, which therefore should support FLOW

        :warns FillerWarning: the height is PACK and the wrapped widget does not support FLOW sizing.
        """
        sizing: set[Sizing] = {Sizing.BOX}
        if self.height_type in {WHSettings.PACK, WHSettings.GIVEN}:
            sizing.add(Sizing.FLOW)

        if self.height_type == WHSettings.PACK:
            body = self.original_widget
            # A body without the "sizing" method is a legacy widget: it is handled by the render path as before.
            if hasattr(body, "sizing") and Sizing.FLOW not in body.sizing():
                warnings.warn(
                    f"WHSettings.PACK height expects a FLOW widget to be used, but received {body!r}",
                    FillerWarning,
                    stacklevel=3,
                )

        return frozenset(sizing)

    def rows(self, size: tuple[int], focus: bool = False) -> int:
        """Flow pack support if FLOW sizing supported.

        :raises FillerError: this Filler wraps a BOX widget, so it has no flow row count.
        """
        if self.height_type == WHSettings.PACK:
            return typing.cast("AbstractFlowWidget", self._original_widget).rows(size, focus) + self.top + self.bottom
        if self.height_type == WHSettings.GIVEN:
            return typing.cast("int", self.height_amount) + self.top + self.bottom
        raise FillerError("Method 'rows' not supported for BOX widgets")  # pragma: no cover

    def _repr_attrs(self) -> dict[str, typing.Any]:
        attrs = {
            **super()._repr_attrs(),
            "valign": simplify_valign(self.valign_type, self.valign_amount),
            "height": simplify_height(self.height_type, self.height_amount),
            "top": self.top,
            "bottom": self.bottom,
            "min_height": self.min_height,
        }
        return remove_defaults(attrs, Filler.__init__)

    def selectable(self) -> bool:
        """Return selectable from body."""
        return self._original_widget.selectable()

    def filler_values(self, size: tuple[int, int] | tuple[int], focus: bool) -> tuple[int, int]:
        """
        Return the number of rows to pad on the top and bottom.

        Override this method to define custom padding behaviour.
        """
        maxcol, maxrow = self.pack(size, focus)

        if self.height_type == WHSettings.PACK:
            height = typing.cast("AbstractFlowWidget", self._original_widget).rows((maxcol,), focus=focus)
            return calculate_top_bottom_filler(
                maxrow,
                self.valign_type,
                self.valign_amount,
                WHSettings.GIVEN,
                height,
                None,
                self.top,
                self.bottom,
            )

        return calculate_top_bottom_filler(
            maxrow,
            self.valign_type,
            self.valign_amount,
            self.height_type,
            typing.cast("int", self.height_amount),
            self.min_height,
            self.top,
            self.bottom,
        )

    def render(
        self,
        size: tuple[int, int] | tuple[int],  # type: ignore[override]
        focus: bool = False,
    ) -> CompositeCanvas:
        """Render self.original_widget with space above and/or below."""
        maxcol, maxrow = self.pack(size, focus)
        top, bottom = self.filler_values(size, focus)

        if self.height_type == WHSettings.PACK:
            canv = self._original_widget.render((maxcol,), focus)
        else:
            canv = self._original_widget.render((maxcol, maxrow - top - bottom), focus)
        canv = CompositeCanvas(canv)

        if maxrow and canv.rows() > maxrow and canv.cursor is not None:
            _cx, cy = canv.cursor
            if cy >= maxrow:
                canv.trim(cy - maxrow + 1, maxrow - top - bottom)
        if canv.rows() > maxrow:
            canv.trim(0, maxrow)
            return canv
        canv.pad_trim_top_bottom(top, bottom)
        return canv

    def keypress(
        self,
        size: tuple[int, int] | tuple[int],  # type: ignore[override]  # box and flow only, no fixed size
        key: str,
    ) -> str | None:
        """Pass keypress to self.original_widget."""
        maxcol, maxrow = self.pack(size, True)
        if self.height_type == WHSettings.PACK:
            return self._original_widget.keypress((maxcol,), key)

        top, bottom = self.filler_values((maxcol, maxrow), True)
        return self._original_widget.keypress((maxcol, maxrow - top - bottom), key)

    def get_cursor_coords(self, size: tuple[int, int] | tuple[int]) -> tuple[int, int] | None:
        """Return cursor coords from self.original_widget if any."""
        maxcol, maxrow = self.pack(size, True)
        if not hasattr(self._original_widget, "get_cursor_coords"):
            return None

        top, bottom = self.filler_values(size, True)
        if self.height_type == WHSettings.PACK:
            coords = self._original_widget.get_cursor_coords((maxcol,))
        else:
            coords = self._original_widget.get_cursor_coords((maxcol, maxrow - top - bottom))
        if not coords:
            return None
        x, y = coords
        if y >= maxrow:
            y = maxrow - 1
        return x, y + top

    def get_pref_col(
        self,
        size: tuple[int, int] | tuple[int],
    ) -> int | Literal["left", "right", Align.LEFT, Align.RIGHT] | None:
        """Return pref_col from self.original_widget if any."""
        maxcol, maxrow = self.pack(size, True)
        if not hasattr(self._original_widget, "get_pref_col"):
            return None

        x: int | Literal["left", "right", Align.LEFT, Align.RIGHT] | None
        if self.height_type == WHSettings.PACK:
            x = self._original_widget.get_pref_col((maxcol,))
        else:
            top, bottom = self.filler_values(size, True)
            x = self._original_widget.get_pref_col((maxcol, maxrow - top - bottom))

        return x

    def move_cursor_to_coords(
        self,
        size: tuple[int, int] | tuple[int],
        col: int | Literal["left", "right", Align.LEFT, Align.RIGHT],
        row: int,
    ) -> bool:
        """Pass to self.original_widget."""
        maxcol, maxrow = self.pack(size, True)
        if not hasattr(self._original_widget, "move_cursor_to_coords"):
            return True

        top, bottom = self.filler_values(size, True)
        if row < top or row >= maxrow - bottom:
            return False

        if self.height_type == WHSettings.PACK:
            target_size: tuple[int] | tuple[int, int] = (maxcol,)
        else:
            target_size = (maxcol, maxrow - top - bottom)

        return typing.cast(
            "bool",
            self._original_widget.move_cursor_to_coords(target_size, col, row - top),
        )

    def mouse_event(
        self,
        size: tuple[int, int] | tuple[int],  # type: ignore[override]
        event: str,
        button: int,
        col: int,
        row: int,
        focus: bool,
    ) -> bool | None:
        """Pass to self.original_widget."""
        maxcol, maxrow = self.pack(size, focus)
        if not hasattr(self._original_widget, "mouse_event"):
            return False

        top, bottom = self.filler_values(size, True)
        if row < top or row >= maxrow - bottom:
            return False

        if self.height_type == WHSettings.PACK:
            return self._original_widget.mouse_event(
                (maxcol,),
                event,
                button,
                col,
                row - top,
                focus,
            )
        return self._original_widget.mouse_event(
            (maxcol, maxrow - top - bottom),
            event,
            button,
            col,
            row - top,
            focus,
        )


def calculate_top_bottom_filler(
    maxrow: int,
    valign_type: Literal["top", "middle", "bottom", "relative", WHSettings.RELATIVE] | VAlign,
    valign_amount: int | None,
    height_type: Literal["given", "relative", "clip", WHSettings.GIVEN, WHSettings.RELATIVE, WHSettings.CLIP],
    height_amount: int,
    min_height: int | None,
    top: int,
    bottom: int,
) -> tuple[int, int]:
    """Return the amount of filler (or clipping) on the top and bottom part of maxrow rows.

    :param maxrow: number of rows available
    :param valign_type: 'top', 'middle', 'bottom', 'relative'
    :param valign_amount: a percentage when align_type=='relative'
    :param height_type: 'given', 'relative', 'clip'
    :param height_amount: a percentage when width_type=='relative' otherwise equal to the height of the widget
    :param min_height: a desired minimum width for the widget or None
    :param top: a fixed number of rows to fill on the top
    :param bottom: a fixed number of rows to fill on the bottom
    :raises TypeError: *valign_type* is relative but no *valign_amount* was given.

    >>> ctbf = calculate_top_bottom_filler
    >>> ctbf(15, "top", 0, "given", 10, None, 2, 0)
    (2, 3)
    >>> ctbf(15, "relative", 0, "given", 10, None, 2, 0)
    (2, 3)
    >>> ctbf(15, "relative", 100, "given", 10, None, 2, 0)
    (5, 0)
    >>> ctbf(15, "middle", 0, "given", 4, None, 2, 0)
    (6, 5)
    >>> ctbf(15, "middle", 0, "given", 18, None, 2, 0)
    (0, 0)
    >>> ctbf(20, "top", 0, "relative", 60, None, 0, 0)
    (0, 8)
    >>> ctbf(20, "relative", 30, "relative", 60, None, 0, 0)
    (2, 6)
    >>> ctbf(20, "relative", 30, "relative", 60, 14, 0, 0)
    (2, 4)
    """
    if valign_type == WHSettings.RELATIVE and valign_amount is None:
        raise TypeError("valign_amount must be specified when valign_type is relative")

    if height_type == WHSettings.RELATIVE:
        maxheight = max(maxrow - top - bottom, 0)
        height = int_scale(height_amount, 101, maxheight + 1)
        if min_height is not None:
            height = max(height, min_height)
    else:
        height = height_amount

    valign: int = {VAlign.TOP: 0, VAlign.MIDDLE: 50, VAlign.BOTTOM: 100}.get(  # type: ignore[assignment]
        valign_type,  # type: ignore[arg-type]  # VAlign keys; relative uses valign_amount default
        valign_amount,  # type: ignore[arg-type]  # valign_amount is not None for relative
    )  # relative + None already filtered above

    # add the remainder of top/bottom to the filler
    filler = maxrow - height - top - bottom
    bottom += int_scale(100 - valign, 101, filler + 1)
    top = maxrow - height - bottom

    # reduce filler if we are clipping an edge
    if bottom < 0 < top:
        shift = min(top, -bottom)
        top -= shift
        bottom += shift
    elif top < 0 < bottom:
        shift = min(bottom, -top)
        bottom -= shift
        top += shift

    # no negative values for filler at the moment
    top = max(top, 0)
    bottom = max(bottom, 0)

    return top, bottom
