"""Widget classes: the base widget API, decorations, containers and basic widgets."""

from __future__ import annotations

import typing

from .ansi_text import ANSIText
from .attr_map import AttrMap, AttrMapError
from .attr_wrap import AttrWrap
from .bar_graph import BarGraph, BarGraphError, BarGraphMeta, GraphVScale, scale_bar_values
from .big_text import BigText
from .box_adapter import BoxAdapter, BoxAdapterError
from .columns import Columns, ColumnsError, ColumnsWarning
from .constants import (
    RELATIVE_100,
    Align,
    MouseButton,
    Severity,
    Sizing,
    ValidationMessage,
    VAlign,
    WHSettings,
    WrapMode,
    normalize_align,
    normalize_height,
    normalize_valign,
    normalize_width,
    simplify_align,
    simplify_height,
    simplify_valign,
    simplify_width,
)
from .container import (
    SelectNavigationListContentsMixin,
    SelectNavigationMixin,
    WidgetContainerListContentsMixin,
    WidgetContainerMixin,
)
from .deque_walker import SimpleDequeWalker, SimpleFocusDequeWalker
from .divider import Divider
from .drop_down import DropDown
from .edit import Edit, EditError, IntEdit
from .filler import Filler, FillerError, FillerWarning, calculate_top_bottom_filler
from .filtered_walker import FilteredListWalker
from .frame import Frame, FrameError
from .grid_flow import GridFlow, GridFlowError, GridFlowWarning
from .line_box import LineBox
from .list_walker import ListWalker, ListWalkerError, SimpleFocusListWalker, SimpleListWalker
from .listbox import ListBox, ListBoxError
from .monitored_deque import MonitoredDeque, MonitoredFocusDeque
from .monitored_list import MonitoredFocusList, MonitoredList
from .notifications import Notification, Notifications
from .overlay import Overlay, OverlayError, OverlayWarning
from .overlay_stack import OverlayStack
from .padding import Padding, PaddingError, PaddingWarning, calculate_left_right_padding
from .pile import Pile, PileError, PileWarning
from .popup import PopUpLauncher, PopUpTarget
from .progress_bar import ProgressBar
from .scrollable import Scrollable, ScrollableError, ScrollBar
from .solid_fill import SolidFill
from .spinner import Spinner
from .table import Table, TableColumn, TableError, TableLayout, TableRow
from .tabs import Tabs, TabsError
from .text import Text, TextError
from .treetools import ParentNode, TreeListBox, TreeNode, TreeWalker, TreeWidget, TreeWidgetError
from .widget import (
    AbstractBoxWidget,
    AbstractFixedWidget,
    AbstractFlowWidget,
    AbstractWidget,
    Widget,
    WidgetError,
    WidgetMeta,
    WidgetWarning,
    WidgetWrap,
    WidgetWrapError,
    delegate_to_widget_mixin,
    fixed_size,
    nocache_widget_render,
    nocache_widget_render_instance,
)
from .widget_decoration import WidgetDecoration, WidgetDisable, WidgetPlaceholder
from .wimp import Button, CheckBox, CheckBoxError, RadioButton, SelectableIcon

__all__ = (
    "ANY",
    "BOTTOM",
    "BOX",
    "CENTER",
    "CLIP",
    "ELLIPSIS",
    "FIXED",
    "FLOW",
    "GIVEN",
    "LEFT",
    "MIDDLE",
    "PACK",
    "RELATIVE",
    "RELATIVE_100",
    "RIGHT",
    "SPACE",
    "TOP",
    "WEIGHT",
    "ANSIText",
    "AbstractBoxWidget",
    "AbstractFixedWidget",
    "AbstractFlowWidget",
    "AbstractWidget",
    "Align",
    "AttrMap",
    "AttrMapError",
    "AttrWrap",
    "BarGraph",
    "BarGraphError",
    "BarGraphMeta",
    "BigText",
    "BoxAdapter",
    "BoxAdapterError",
    "Button",
    "CheckBox",
    "CheckBoxError",
    "Columns",
    "ColumnsError",
    "ColumnsWarning",
    "Divider",
    "DropDown",
    "Edit",
    "EditError",
    "Filler",
    "FillerError",
    "FillerWarning",
    "FilteredListWalker",
    "Frame",
    "FrameError",
    "GraphVScale",
    "GridFlow",
    "GridFlowError",
    "GridFlowWarning",
    "IntEdit",
    "LineBox",
    "ListBox",
    "ListBoxError",
    "ListWalker",
    "ListWalkerError",
    "MonitoredDeque",
    "MonitoredFocusDeque",
    "MonitoredFocusList",
    "MonitoredList",
    "MouseButton",
    "Notification",
    "Notifications",
    "Overlay",
    "OverlayError",
    "OverlayStack",
    "OverlayWarning",
    "Padding",
    "PaddingError",
    "PaddingWarning",
    "ParentNode",
    "Pile",
    "PileError",
    "PileWarning",
    "PopUpLauncher",
    "PopUpTarget",
    "ProgressBar",
    "RadioButton",
    "ScrollBar",
    "Scrollable",
    "ScrollableError",
    "SelectNavigationListContentsMixin",
    "SelectNavigationMixin",
    "SelectableIcon",
    "Severity",
    "SimpleDequeWalker",
    "SimpleFocusDequeWalker",
    "SimpleFocusListWalker",
    "SimpleListWalker",
    "Sizing",
    "SolidFill",
    "Spinner",
    "Table",
    "TableColumn",
    "TableError",
    "TableLayout",
    "TableRow",
    "Tabs",
    "TabsError",
    "Text",
    "TextError",
    "TreeListBox",
    "TreeNode",
    "TreeWalker",
    "TreeWidget",
    "TreeWidgetError",
    "VAlign",
    "ValidationMessage",
    "WHSettings",
    "Widget",
    "WidgetContainerListContentsMixin",
    "WidgetContainerMixin",
    "WidgetDecoration",
    "WidgetDisable",
    "WidgetError",
    "WidgetMeta",
    "WidgetPlaceholder",
    "WidgetWarning",
    "WidgetWrap",
    "WidgetWrapError",
    "WrapMode",
    "calculate_left_right_padding",
    "calculate_top_bottom_filler",
    "delegate_to_widget_mixin",
    "fixed_size",
    "nocache_widget_render",
    "nocache_widget_render_instance",
    "normalize_align",
    "normalize_height",
    "normalize_valign",
    "normalize_width",
    "scale_bar_values",
    "simplify_align",
    "simplify_height",
    "simplify_valign",
    "simplify_width",
)

# Backward compatibility aliases of the enum members. Not deprecated: too widely used to be removed.
FLOW: typing.Literal[Sizing.FLOW] = Sizing.FLOW
BOX: typing.Literal[Sizing.BOX] = Sizing.BOX
FIXED: typing.Literal[Sizing.FIXED] = Sizing.FIXED

LEFT: typing.Literal[Align.LEFT] = Align.LEFT
RIGHT: typing.Literal[Align.RIGHT] = Align.RIGHT
CENTER: typing.Literal[Align.CENTER] = Align.CENTER

TOP: typing.Literal[VAlign.TOP] = VAlign.TOP
MIDDLE: typing.Literal[VAlign.MIDDLE] = VAlign.MIDDLE
BOTTOM: typing.Literal[VAlign.BOTTOM] = VAlign.BOTTOM

SPACE: typing.Literal[WrapMode.SPACE] = WrapMode.SPACE
ANY: typing.Literal[WrapMode.ANY] = WrapMode.ANY
CLIP: typing.Literal[WrapMode.CLIP] = WrapMode.CLIP
ELLIPSIS: typing.Literal[WrapMode.ELLIPSIS] = WrapMode.ELLIPSIS

PACK: typing.Literal[WHSettings.PACK] = WHSettings.PACK
GIVEN: typing.Literal[WHSettings.GIVEN] = WHSettings.GIVEN
RELATIVE: typing.Literal[WHSettings.RELATIVE] = WHSettings.RELATIVE
WEIGHT: typing.Literal[WHSettings.WEIGHT] = WHSettings.WEIGHT
